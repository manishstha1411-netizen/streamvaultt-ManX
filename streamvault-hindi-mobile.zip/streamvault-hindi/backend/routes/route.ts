import express from "express";
import mediaInfo from "../controllers/mediaInfo";
import getStream from "../controllers/getStream";
import { createProxyMiddleware } from "http-proxy-middleware";
import getSeasonList from "../controllers/getSeasonList";
import {
  awiHome,
  awiSearch,
  awiSeasons,
  awiEpisodes,
  awiStream,
  awiA2Z,
} from "../controllers/awiScraper";

const router = express.Router();

// ── Original 8Stream routes ──────────────────────────────────────────────────
router.get("/mediaInfo", mediaInfo);
router.post("/getStream", getStream);
router.get("/getSeasonList", getSeasonList);

// ── AnimeWorld India (Hindi Dub) routes ─────────────────────────────────────
// ⚠️  These scrape animeworld-india.me. May break if the site changes.
router.get("/awi/home",     awiHome);
router.get("/awi/search",   awiSearch);
router.get("/awi/seasons",  awiSeasons);
router.get("/awi/episodes", awiEpisodes);
router.get("/awi/stream",   awiStream);
router.get("/awi/a2z",      awiA2Z);

export default router;
