/**
 * AnimeWorld India API — Node/Express replacement for the PHP scraper layer.
 *
 * ⚠️  This scrapes animeworld-india.me.  It may break if the upstream site
 *     changes its HTML structure.  Use as a supplementary Hindi-dub source only.
 *
 * Endpoints (all GET, mounted at /api/awi/):
 *   /home           — latest series + movies on homepage
 *   /search         — ?query=<str>&p=<n>
 *   /series         — ?p=<n>
 *   /movie          — ?p=<n>
 *   /seasons        — ?seriesID=<slug>
 *   /episodes       — ?seasonId=<slug>
 *   /stream         — ?episodeId=<slug>  OR  ?movieId=<slug>
 *   /a2z            — ?letter=<a-z|0-9>&p=<n>
 */

import axios from "axios";
import * as cheerio from "cheerio";
import { Request, Response } from "express";

const BASE = "https://watchanimeworld.net";
const TIMEOUT = Number(process.env.AWI_TIMEOUT_MS) || 15_000;

// ─── Shared fetch helper ──────────────────────────────────────────────────────
async function fetchHtml(url: string): Promise<string> {
  const res = await axios.get(url, {
    timeout: TIMEOUT,
    headers: {
      "User-Agent":
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
        "(KHTML, like Gecko) Chrome/124.0 Safari/537.36",
      Accept:
        "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
      "Accept-Language": "en-US,en;q=0.9",
      Referer: "https://google.com/",
    },
  });
  return res.data as string;
}

function err(res: Response, message: string, status = 502) {
  return res.status(status).json({ success: false, error: message });
}

// ─── /home ────────────────────────────────────────────────────────────────────
export async function awiHome(req: Request, res: Response) {
  try {
    const html = await fetchHtml(BASE);
    const $ = cheerio.load(html);

    const parseRow = (selector: string, type: "series" | "movie") =>
      $(selector)
        .toArray()
        .slice(0, 12)
        .map((el) => {
          const a = $(el).find("a.lnk-blk");
          const href = a.attr("href") || "";
          const slug = href.replace(`/${type}/`, "").replace(/\/$/, "");
          return {
            title: $(el).find("h2.entry-title").text().trim() || null,
            image: $(el).find("img").attr("src") || null,
            year: $(el).find(".year").text().trim() || null,
            rating: $(el).find(".vote").text().trim() || null,
            [`${type}Id`]: slug || null,
          };
        });

    res.json({
      success: true,
      source: "animeworld-india.me",
      latest_series: parseRow(
        "ul.post-lst li.status-publish:has(a[href*='/series/'])",
        "series"
      ),
      latest_movies: parseRow(
        "ul.post-lst li.status-publish:has(a[href*='/movie/'])",
        "movie"
      ),
    });
  } catch (e: any) {
    err(res, e.message);
  }
}

// ─── /search ─────────────────────────────────────────────────────────────────
export async function awiSearch(req: Request, res: Response) {
  const query = String(req.query.query || "").trim();
  const page = Number(req.query.p) || 1;
  if (!query) return err(res, "Missing query parameter", 400);

  try {
    const html = await fetchHtml(
      `${BASE}/?s=${encodeURIComponent(query)}${page > 1 ? `&paged=${page}` : ""}`
    );
    const $ = cheerio.load(html);

    const results = $("ul.post-lst li.status-publish")
      .toArray()
      .map((li) => {
        const a = $(li).find("a.lnk-blk");
        const href = a.attr("href") || "";
        const title = $(li).find("h2.entry-title").text().trim() || null;
        let image = $(li).find("img").attr("src") || null;

if (image && image.startsWith("//")) {
  image = "https:" + image;
}
        const year = $(li).find(".year").text().trim() || null;
        const rating = $(li).find(".vote").text().trim() || null;

        let type: string | null = null;
        let seriesId: string | null = null;
        let movieId: string | null = null;

        if (href.includes("/series/")) {
          type = "series";
          seriesId = href.replace(/.*\/series\//, "").replace(/\/$/, "");
        } else if (href.includes("/movie/")) {
          type = "movie";
          movieId = href.replace(/.*\/movie\//, "").replace(/\/$/, "");
        }

        return { title, image, year, rating, type, seriesId, movieId };
      })
      .filter((r) => r.type);

    // Pagination
    const pageNums: number[] = [];
    $("nav.pagination a.page-link").each((_, el) => {
      const n = Number($(el).text().trim());
      if (!isNaN(n) && n > 0) pageNums.push(n);
    });
    const totalPages = pageNums.length ? Math.max(...pageNums) : null;

    res.json({
      success: true,
      query,
      currentPage: page,
      totalPages,
      hasNextPage: totalPages ? page < totalPages : false,
      source: "animeworld-india.me/search",
      results,
    });
  } catch (e: any) {
    err(res, e.message);
  }
}

// ─── /seasons ─────────────────────────────────────────────────────────────────
export async function awiSeasons(req: Request, res: Response) {
  const seriesID = String(req.query.seriesID || "").trim();
  if (!seriesID) return err(res, "Missing seriesID parameter", 400);

  try {
    const html = await fetchHtml(`${BASE}/series/${seriesID}`);
    const $ = cheerio.load(html);

    const title =
      $("h1.entry-title").first().text().trim() ||
      $(".entry-title").first().text().trim() ||
      null;
    const poster =
      $(".post-thumbnail img").first().attr("src") ||
      $(".wp-post-image").first().attr("src") ||
      null;
    const year = $(".year").first().text().trim() || null;
    const rating = $(".vote .num").first().text().trim() || null;
    const description =
      $(".description p").first().text().trim() ||
      $(".entry-content p").first().text().trim() ||
      null;
    const duration = $(".duration").first().text().trim() || null;

    const seasons: any[] = [];
    // Seasons are usually listed as links like /season/seriesID-season-1
    $("a[href*='-season-']").each((_, el) => {
      const href = $(el).attr("href") || "";
      const slug = href.replace(/.*\/season\//, "").replace(/\/$/, "");
      const text = $(el).text().trim();
      const epMatch = text.match(/(\d+)\s*ep/i);
      if (slug && !seasons.find((s) => s.seasonId === slug)) {
        seasons.push({
          seasonNumber: (seasons.length + 1).toString(),
          seasonName:
            text || `Season ${seasons.length + 1}`,
          episodes: epMatch ? `${epMatch[1]} Episodes` : "Episodes",
          seasonId: slug,
        });
      }
    });

    // Fallback: look for season links in post content
    if (seasons.length === 0) {
      $(".entry-content a, .post-content a").each((_, el) => {
        const href = $(el).attr("href") || "";
        if (href.includes("/season/")) {
          const slug = href.replace(/.*\/season\//, "").replace(/\/$/, "");
          const text = $(el).text().trim();
          if (slug && !seasons.find((s) => s.seasonId === slug)) {
            seasons.push({
              seasonNumber: (seasons.length + 1).toString(),
              seasonName: text || `Season ${seasons.length + 1}`,
              episodes: "Episodes",
              seasonId: slug,
            });
          }
        }
      });
    }

    const totalSeasons = seasons.length.toString();

    res.json({
      success: true,
      source: "animeworld-india.me/series",
      series: {
        seriesId: seriesID,
        title,
        poster,
        year,
        duration,
        rating,
        totalSeasons,
        description,
      },
      seasons,
    });
  } catch (e: any) {
    err(res, e.message);
  }
}

// ─── /episodes ────────────────────────────────────────────────────────────────
export async function awiEpisodes(req: Request, res: Response) {
  const seasonId = String(req.query.seasonId || "").trim();
  if (!seasonId) return err(res, "Missing seasonId parameter", 400);

  try {
    const html = await fetchHtml(`${BASE}/season/${seasonId}`);
    const $ = cheerio.load(html);

    const seasonName =
      $("h1.entry-title").first().text().trim() ||
      $(".entry-title").first().text().trim() ||
      seasonId;
    const animeTitle =
      $(".breadcrumb a").eq(-2).text().trim() ||
      seasonName.replace(/Season.*/, "").trim();
    const rating = $(".vote .num").first().text().trim() || null;
    const duration = $(".duration").first().text().trim() || null;
    const poster =
      $(".post-thumbnail img").first().attr("src") ||
      $(".wp-post-image").first().attr("src") ||
      null;
    const description =
      $(".description p").first().text().trim() ||
      $(".entry-content p").first().text().trim() ||
      null;

    const episodes: any[] = [];
    // Episodes listed as links to /episode/slug
    $("a[href*='/episode/']").each((_, el) => {
      const href = $(el).attr("href") || "";
      const slug = href.replace(/.*\/episode\//, "").replace(/\/$/, "");
      const text = $(el).text().trim();
      if (slug && !episodes.find((e) => e.episodeId === slug)) {
        const epNumMatch = slug.match(/episode-(\d+)/i);
        const epNum = epNumMatch ? epNumMatch[1] : String(episodes.length + 1);
        episodes.push({
          episodeId: slug,
          title: text || `Episode ${epNum}`,
          episodeNumber: `Episode ${epNum}`,
          airDate: null,
          image: null,
          overview: null,
        });
      }
    });

    // Sort by episode number
    episodes.sort((a, b) => {
      const na = parseInt(a.episodeNumber.replace(/\D/g, "") || "0");
      const nb = parseInt(b.episodeNumber.replace(/\D/g, "") || "0");
      return na - nb;
    });

    res.json({
      success: true,
      source: "animeworld-india.me/season",
      season: {
        seasonId,
        animeTitle,
        seasonName,
        totalEpisodes: String(episodes.length),
        rating,
        duration,
        poster,
        description,
      },
      episodes,
    });
  } catch (e: any) {
    err(res, e.message);
  }
}

// ─── /stream ──────────────────────────────────────────────────────────────────
export async function awiStream(req: Request, res: Response) {
  const episodeId = String(req.query.episodeId || "").trim();
  const movieId = String(req.query.movieId || "").trim();

  if (!episodeId && !movieId)
    return err(res, "Missing episodeId or movieId", 400);

  const type = episodeId ? "episode" : "movie";
  const targetUrl = episodeId
    ? `${BASE}/episode/${episodeId}`
    : `${BASE}/movie/${movieId}`;

  try {
    const html = await fetchHtml(targetUrl);
    const $ = cheerio.load(html);

    // Stream iframe src — also check data-src for lazy-loaded iframes
    const streamLink =
      $(".video-embed iframe").first().attr("src") ||
      $(".video-embed iframe").first().attr("data-src") ||
      $("iframe[src*='player']").first().attr("src") ||
      $("iframe[data-src*='player']").first().attr("data-src") ||
      $("iframe").first().attr("src") ||
      $("iframe").first().attr("data-src") ||
      null;

    // Download link
    const downloadLink =
      $(".archive-link-wrap a").first().attr("href") ||
      $("a[href$='.mp4']").first().attr("href") ||
      null;

    if (type === "movie") {
      const title =
        $("h1.entry-title").first().text().trim() ||
        $(".entry-title").first().text().trim() ||
        null;
      const poster =
        $(".post-thumbnail img").first().attr("src") ||
        $(".wp-post-image").first().attr("src") ||
        null;
      const description =
        $(".description p").first().text().trim() ||
        $(".entry-content p").first().text().trim() ||
        null;
      const year = $(".year").first().text().trim() || null;
      const duration = $(".duration").first().text().trim() || null;
      const rating = $(".vote .num").first().text().trim() || null;

      return res.json({
        success: !!streamLink,
        type: "movie",
        source: "animeworld-india.me/movie",
        movie: { movieId, title, poster, description, year, duration, rating },
        stream: { streamLink, file: downloadLink },
        ...(streamLink ? {} : { error: "Could not extract stream link" }),
      });
    }

    // Episode mode
    const seriesTitle =
      $(".breadcrumb a").eq(-3).text().trim() ||
      $("h1.entry-title").first().text().trim() ||
      null;
    const seasonName = $(".breadcrumb a").eq(-2).text().trim() || null;
    const poster =
      $(".post-thumbnail img").first().attr("src") ||
      $(".wp-post-image").first().attr("src") ||
      null;
    const rating = $(".vote .num").first().text().trim() || null;
    const duration = $(".duration").first().text().trim() || null;
    const description =
      $(".description p").first().text().trim() ||
      $(".entry-content p").first().text().trim() ||
      null;

    const epTitle =
      $("h1.entry-title").first().text().trim() ||
      $(".entry-title").first().text().trim() ||
      null;
    const airDate = $(".date").first().text().trim() || null;

    // Sibling episode links
    const allEps: any[] = [];
    $("a[href*='/episode/']").each((_, el) => {
      const href = $(el).attr("href") || "";
      const slug = href.replace(/.*\/episode\//, "").replace(/\/$/, "");
      const text = $(el).text().trim();
      if (slug && !allEps.find((e) => e.episodeId === slug)) {
        const num = slug.match(/episode-(\d+)/i)?.[1] || String(allEps.length + 1);
        allEps.push({ episodeId: slug, title: text || `Episode ${num}`, episodeNumber: `Episode ${num}`, airDate: null, image: null });
      }
    });
    allEps.sort((a, b) => {
      const na = parseInt(a.episodeNumber.replace(/\D/g, "") || "0");
      const nb = parseInt(b.episodeNumber.replace(/\D/g, "") || "0");
      return na - nb;
    });

    const curIdx = allEps.findIndex((e) => e.episodeId === episodeId);

    return res.json({
      success: !!streamLink,
      type: "episode",
      source: "animeworld-india.me/episode",
      series: { title: seriesTitle, poster, season: seasonName, rating, duration, description },
      current: { episodeId, title: epTitle, airDate, overview: description },
      previous: curIdx > 0 ? allEps[curIdx - 1].episodeId : null,
      next: curIdx >= 0 && curIdx < allEps.length - 1 ? allEps[curIdx + 1].episodeId : null,
      episodes: allEps,
      stream: { streamLink, file: downloadLink },
      ...(streamLink ? {} : { error: "Could not extract stream link" }),
    });
  } catch (e: any) {
    err(res, e.message);
  }
}

// ─── /a2z ─────────────────────────────────────────────────────────────────────
export async function awiA2Z(req: Request, res: Response) {
  const letter = String(req.query.letter || "a").trim().toLowerCase();
  const page = Number(req.query.p) || 1;

  try {
    const html = await fetchHtml(`${BASE}/a-z/${letter}?page=${page}`);
    const $ = cheerio.load(html);

    const results = $("ul.post-lst li.status-publish")
      .toArray()
      .map((li) => {
        const a = $(li).find("a.lnk-blk");
        const href = a.attr("href") || "";
        const title = $(li).find("h2.entry-title").text().trim() || null;
        const poster = $(li).find("img").attr("src") || null;
        const year = $(li).find(".year").text().trim() || null;
        const rating = $(li).find(".vote").text().trim() || null;
        let type = null, id = null;
        if (href.includes("/series/")) {
          type = "series";
          id = href.replace(/.*\/series\//, "").replace(/\/$/, "");
        } else if (href.includes("/movie/")) {
          type = "movie";
          id = href.replace(/.*\/movie\//, "").replace(/\/$/, "");
        }
        return { title, poster, year, rating, type, id };
      })
      .filter((r) => r.type);

    res.json({ success: true, letter, page, results });
  } catch (e: any) {
    err(res, e.message);
  }
}
