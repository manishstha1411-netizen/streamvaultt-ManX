import React from "react";
import { createRoot } from "react-dom/client";
import StreamVault from "./StreamVault.jsx";

createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <StreamVault />
  </React.StrictMode>
);
