
// ============================================================
// StreamVault — Complete Streaming App (Movies · TV · Anime)
// All-in-one: Frontend + Backend API calls + Full UI
// ============================================================

import { useState, useEffect, useCallback, useRef } from "react";

// ─── CSS Variables / Theme ────────────────────────────────────────────────────
const DARK = {
  "--bg":      "#0a0a0f",
  "--bg2":     "#111118",
  "--bg3":     "#1a1a26",
  "--bg4":     "#22223a",
  "--border":  "#2a2a3a",
  "--text":    "#f0f0f0",
  "--text2":   "#8080a0",
  "--accent":  "#7c6aff",
  "--accent2": "#a855f7",
  "--green":   "#22c55e",
  "--red":     "#ef4444",
  "--yellow":  "#f59e0b",
  "--cyan":    "#06b6d4",
};
const LIGHT = {
  "--bg":      "#f4f4f8",
  "--bg2":     "#ffffff",
  "--bg3":     "#eeeef5",
  "--bg4":     "#e4e4ef",
  "--border":  "#dddde8",
  "--text":    "#111122",
  "--text2":   "#666688",
  "--accent":  "#6c5aef",
  "--accent2": "#9444d4",
  "--green":   "#16a34a",
  "--red":     "#dc2626",
  "--yellow":  "#d97706",
  "--cyan":    "#0891b2",
};

// ─── Inline styles helper ─────────────────────────────────────────────────────
const px = (obj) => Object.entries(obj).map(([k,v])=>`${k}:${v}`).join(";");

// ─── TMDB API ─────────────────────────────────────────────────────────────────
const TMDB_KEY = "00f39bbbf9b18eaeeeabf8d2230b6403";
const TMDB = "https://api.themoviedb.org/3";
const IMG  = "https://image.tmdb.org/t/p";

async function tmdb(path, params={}) {
  const url = new URL(`${TMDB}${path}`);
  url.searchParams.set("api_key", TMDB_KEY);
  Object.entries(params).forEach(([k,v]) => url.searchParams.set(k,v));
  const r = await fetch(url.toString());
  if (!r.ok) throw new Error(`TMDB ${r.status}`);
  return r.json();
}

const posterUrl  = (p, s="w342")  => p ? `${IMG}/${s}${p}` : null;
const backdropUrl= (p, s="w1280") => p ? `${IMG}/${s}${p}` : null;
const formatRuntime = (m) => !m ? null : m>=60 ? `${Math.floor(m/60)}h ${m%60}m` : `${m}m`;
const formatMoney = (n) => !n||n===0 ? null : n>=1e9 ? `$${(n/1e9).toFixed(1)}B` : n>=1e6 ? `$${(n/1e6).toFixed(0)}M` : `$${n.toLocaleString()}`;

async function getMovieDetail(id) {
  const [det,creds,vids,sim,ext] = await Promise.all([
    tmdb(`/movie/${id}`),
    tmdb(`/movie/${id}/credits`),
    tmdb(`/movie/${id}/videos`),
    tmdb(`/movie/${id}/similar`),
    tmdb(`/movie/${id}/external_ids`),
  ]);
  return {...det, credits:creds, videos:vids.results||[], similar:sim.results||[], imdb_id:ext.imdb_id||null};
}
async function getTVDetail(id) {
  const [det,creds,vids,sim,ext] = await Promise.all([
    tmdb(`/tv/${id}`),
    tmdb(`/tv/${id}/credits`),
    tmdb(`/tv/${id}/videos`),
    tmdb(`/tv/${id}/similar`),
    tmdb(`/tv/${id}/external_ids`),
  ]);
  return {...det, credits:creds, videos:vids.results||[], similar:sim.results||[], imdb_id:ext.imdb_id||null};
}
async function getTVSeason(id, s) { return tmdb(`/tv/${id}/season/${s}`); }
async function getTrendingMovies()  { return (await tmdb("/trending/movie/week")).results||[]; }
async function getTrendingTV()      { return (await tmdb("/trending/tv/week")).results||[]; }
async function getTopRatedMovies()  { return (await tmdb("/movie/top_rated")).results||[]; }
async function getNowPlaying()      { return (await tmdb("/movie/now_playing")).results||[]; }
async function getPopularTV()       { return (await tmdb("/tv/popular")).results||[]; }
async function searchAll(q)         { return ((await tmdb("/search/multi",{query:q,include_adult:false})).results||[]).filter(r=>r.media_type!=="person"); }

// ─── AniList API ──────────────────────────────────────────────────────────────
const AL = "https://graphql.anilist.co";
async function anilist(query, variables={}) {
  const r = await fetch(AL,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({query,variables})});
  return (await r.json())?.data;
}
const AL_FIELDS = `id title{romaji english} episodes averageScore coverImage{large extraLarge} bannerImage genres format season seasonYear status description(asHtml:false)`;
async function getTrendingAnime() {
  const d = await anilist(`query{Page(page:1,perPage:15){media(type:ANIME,sort:TRENDING_DESC,status:RELEASING){${AL_FIELDS}}}}`);
  return d?.Page?.media||[];
}
async function getPopularAnime() {
  const d = await anilist(`query{Page(page:1,perPage:15){media(type:ANIME,sort:POPULARITY_DESC){${AL_FIELDS}}}}`);
  return d?.Page?.media||[];
}
async function searchAnime(search) {
  const d = await anilist(`query($search:String){Page(page:1,perPage:20){media(search:$search,type:ANIME,sort:POPULARITY_DESC){${AL_FIELDS}}}}`,{search});
  return d?.Page?.media||[];
}
async function getAnimeDetail(id) {
  const d = await anilist(`query($id:Int){Media(id:$id,type:ANIME){${AL_FIELDS} idMal studios(isMain:true){nodes{name}} trailer{id site} relations{edges{relationType node{id title{romaji english} coverImage{large} type format}}}}}`,{id:Number(id)});
  return d?.Media||null;
}

// ─── AnimeWorld India API (Hindi Dub source) ────────────────────────────────
// ⚠️  This source scrapes animeworld-india.me via the Express backend.
//     It may break if the upstream site changes its HTML structure.
//     Use as a supplementary Hindi-dub tab only.
//
// In development the Vite proxy forwards /api/v1/awi → localhost:5001.
// In production set VITE_API_BASE to your deployed backend URL.

const AWI_BASE_URL = (import.meta.env.VITE_API_BASE || "").replace(/\/$/, "");

async function awiGet(path, params = {}) {
  const url = new URL(`${AWI_BASE_URL}/api/v1/awi/${path}`, window.location.origin);
  Object.entries(params).forEach(([k, v]) => url.searchParams.set(k, String(v)));
  console.log(`[AWI →] ${url.toString()}`);
  const t0 = Date.now();
  const r = await fetch(url.toString());
  if (!r.ok) {
    console.error(`[AWI ✗] ${path} — HTTP ${r.status} ${r.statusText}`);
    throw new Error(`AWI backend ${r.status}: ${r.statusText}`);
  }
  const data = await r.json();
  console.log(`[AWI ✓] ${path} — ${Date.now() - t0}ms`, data);
  return data;
}

async function awiSearch(query, page = 1) {
  return awiGet("search", { query, p: page });
}
async function awiSeasons(seriesId) {
  return awiGet("seasons", { seriesID: seriesId });
}
async function awiEpisodes(seasonId) {
  return awiGet("episodes", { seasonId });
}
async function awiStream(opts) {
  // opts = { episodeId } or { movieId }
  return awiGet("stream", opts);
}

// ─── Language config ──────────────────────────────────────────────────────────
// ─── Language config ──────────────────────────────────────────────────────────
// langs: list of audio languages each server supports
// priority: higher = shown first when matching user preferred language
const LANGS = {
  en:"🇬🇧 English", hi:"🇮🇳 Hindi", es:"🇪🇸 Spanish",
  fr:"🇫🇷 French",  ar:"🇸🇦 Arabic", pt:"🇧🇷 Portuguese",
  de:"🇩🇪 German",  ru:"🇷🇺 Russian",ja:"🇯🇵 Japanese",
  ko:"🇰🇷 Korean",  zh:"🇨🇳 Chinese",it:"🇮🇹 Italian",
  tr:"🇹🇷 Turkish", pl:"🇵🇱 Polish", nl:"🇳🇱 Dutch",
};

// ─── Stream Sources ───────────────────────────────────────────────────────────
// `langParam: "ds_lang"` means this provider accepts a real ?ds_lang=<code> query
// param that preselects the subtitle/audio track inside its own player.
// Sources without langParam can only be "matched" by reordering (no in-player switch).
function getMovieSources(tmdbId, imdbId) {
  const s=[];
  if(tmdbId){
    s.push({name:"VidSrc.to",    quality:"4K", langs:["en","hi","es","fr","ar","de","ru","pt","tr","it","pl","nl"], langParam:"ds_lang", url:`https://vidsrc.to/embed/movie/${tmdbId}`});
    s.push({name:"AutoEmbed",    quality:"HD", langs:["en","hi","es","fr","ar","de"],                           url:`https://player.autoembed.cc/embed/movie/${tmdbId}`});
    s.push({name:"MoviesAPI",    quality:"HD", langs:["en","hi","es","fr","de","ar"],                           url:`https://moviesapi.club/movie/${tmdbId}`});
    s.push({name:"VidSrc.vip",   quality:"HD", langs:["en","hi","es","fr","de","ru","pt","tr","it","pl","nl"],  langParam:"ds_lang", url:`https://vidsrc.vip/embed/movie/${tmdbId}`});
  }
  if(imdbId){
    s.push({name:"EmbedSu",      quality:"HD", langs:["en","hi","es","fr","de","pt","ru","it","tr"],            url:`https://embed.su/embed/movie/${imdbId}`});
    s.push({name:"SmashyStream", quality:"HD", langs:["en","hi","ar","es","fr","de","ru","pt","tr"],            url:`https://player.smashy.stream/movie/${imdbId}`});
    s.push({name:"SuperEmbed",   quality:"HD", langs:["en","hi","es","fr","ar","de","ru","pt"],                 url:`https://multiembed.mov/?video_id=${imdbId}&tmdb=1`});
    s.push({name:"2Embed",       quality:"HD", langs:["en","hi","es","fr","ar","de","ru","pt"],                 url:`https://www.2embed.cc/embed/${imdbId}`});
    s.push({name:"VidSrc Pro",   quality:"4K", langs:["en","hi","es","fr","ar","de","ru","pt","tr","it","pl"],  langParam:"ds_lang", url:`https://vidsrc.xyz/embed/movie?imdb=${imdbId}`});
    s.push({name:"VidSrc.cc",    quality:"4K", langs:["en","hi","es","fr","ar","de","ru","pt","tr","it"],       langParam:"ds_lang", url:`https://vidsrc.cc/v2/embed/movie/${imdbId}`});
  }
  if(tmdbId){
    s.push({name:"VidSrc.me",    quality:"HD", langs:["en","hi","es","fr","ar","de","ru","pt","tr","it"],       langParam:"ds_lang", url:`https://vidsrc.me/embed/movie?tmdb=${tmdbId}`});
    s.push({name:"NontonGo",     quality:"HD", langs:["en","hi","es","fr"],                                     url:`https://www.nontongo.win/embed/movie/${tmdbId}`});
  }
  return s;
}
function getTVSources(tmdbId, imdbId, season=1, episode=1) {
  const s=[], se=season||1, ep=episode||1;
  if(tmdbId){
    s.push({name:"VidSrc.to",    quality:"4K", langs:["en","hi","es","fr","ar","de","ru","pt","tr","it","pl","nl"], langParam:"ds_lang", url:`https://vidsrc.to/embed/tv/${tmdbId}/${se}/${ep}`});
    s.push({name:"AutoEmbed",    quality:"HD", langs:["en","hi","es","fr","ar","de"],                            url:`https://player.autoembed.cc/embed/tv/${tmdbId}/${se}/${ep}`});
    s.push({name:"MoviesAPI",    quality:"HD", langs:["en","hi","es","fr","de","ar"],                            url:`https://moviesapi.club/tv/${tmdbId}-${se}-${ep}`});
    s.push({name:"VidSrc.vip",   quality:"HD", langs:["en","hi","es","fr","de","ru","pt","tr","it","pl","nl"],   langParam:"ds_lang", url:`https://vidsrc.vip/embed/tv/${tmdbId}/${se}/${ep}`});
  }
  if(imdbId){
    s.push({name:"EmbedSu",      quality:"HD", langs:["en","hi","es","fr","de","pt","ru","it","tr"],             url:`https://embed.su/embed/tv/${imdbId}/${se}/${ep}`});
    s.push({name:"SmashyStream", quality:"HD", langs:["en","hi","ar","es","fr","de","ru","pt","tr"],             url:`https://player.smashy.stream/tv/${imdbId}?s=${se}&e=${ep}`});
    s.push({name:"SuperEmbed",   quality:"HD", langs:["en","hi","es","fr","ar","de","ru","pt"],                  url:`https://multiembed.mov/?video_id=${imdbId}&tmdb=1&s=${se}&e=${ep}`});
    s.push({name:"2Embed",       quality:"HD", langs:["en","hi","es","fr","ar","de","ru","pt"],                  url:`https://www.2embed.cc/embedtv/${imdbId}&s=${se}&e=${ep}`});
    s.push({name:"VidSrc Pro",   quality:"4K", langs:["en","hi","es","fr","ar","de","ru","pt","tr","it","pl"],   langParam:"ds_lang", url:`https://vidsrc.xyz/embed/tv?imdb=${imdbId}&season=${se}&episode=${ep}`});
    s.push({name:"VidSrc.cc",    quality:"4K", langs:["en","hi","es","fr","ar","de","ru","pt","tr","it"],        langParam:"ds_lang", url:`https://vidsrc.cc/v2/embed/tv/${imdbId}/${se}/${ep}`});
  }
  if(tmdbId){
    s.push({name:"VidSrc.me",    quality:"HD", langs:["en","hi","es","fr","ar","de","ru","pt","tr","it"],        langParam:"ds_lang", url:`https://vidsrc.me/embed/tv?tmdb=${tmdbId}&season=${se}&episode=${ep}`});
    s.push({name:"NontonGo",     quality:"HD", langs:["en","hi","es","fr"],                                      url:`https://www.nontongo.win/embed/tv/${tmdbId}/${se}/${ep}`});
  }
  return s;
}

// ─── Apply preferred-language param to a source's URL where supported ─────────
// Returns a new source object whose url has ?ds_lang=<lang> appended, if and
// only if this provider supports the param AND advertises that language.
function withLang(source, lang) {
  if(!source || !lang || !source.langParam) return source;
  if(!(source.langs||[]).includes(lang)) return source;
  try {
    const u = new URL(source.url);
    u.searchParams.set(source.langParam, lang);
    return {...source, url: u.toString()};
  } catch { return source; }
}
function buildSlug(title) {
  return (title||"").toLowerCase().replace(/[^a-z0-9\s-]/g,"").trim().replace(/\s+/g,"-");
}
function getAnimeSources(title, episode=1, malId=null, aniId=null) {
  const slug=buildSlug(title), ep=episode||1, s=[];
  if(malId){
    s.push({name:"MalSync",      quality:"HD", langs:["ja","en"],                   url:`https://malsync.moe/embed/anime/${malId}/${ep}`});
    s.push({name:"AnimeKai",     quality:"HD", langs:["ja","en","hi"],               url:`https://animekai.to/embed/mal/${malId}/ep/${ep}`});
    s.push({name:"AniPlay",      quality:"HD", langs:["ja","en","hi"],               url:`https://aniplay.co/embed/${malId}/${ep}`});
  }
  if(aniId){
    s.push({name:"AniWatch",     quality:"HD", langs:["ja","en","hi"],               url:`https://aniwatch.to/embed-2?id=${aniId}&ep=${ep}`});
  }
  s.push({name:"HiAnime",        quality:"HD", langs:["ja","en","hi"],               url:`https://hianime.to/watch/${slug}-episode-${ep}`});
  s.push({name:"GogoAnime",      quality:"HD", langs:["ja","en","hi"],               url:`https://gogoanime3.co/${slug}-episode-${ep}`});
  s.push({name:"9AnimeTV",       quality:"HD", langs:["ja","en","hi"],               url:`https://9animetv.to/watch/${slug}-${ep}`});
  s.push({name:"AnimePahe",      quality:"HD", langs:["ja","en"],                    url:`https://animepahe.ru/anime/${slug}`});
  s.push({name:"AllAnime",       quality:"HD", langs:["ja","en","hi"],               url:`https://allanime.to/anime/${slug}/episode-${ep}`});
  s.push({name:"KickAssAnime",   quality:"HD", langs:["ja","en","hi"],               url:`https://kickassanime.am/anime/${slug}/episode-${ep}`});
  s.push({name:"AnimeOwl",       quality:"HD", langs:["ja","en","hi"],               url:`https://animeowl.me/anime/${slug}/episode-${ep}`});
  s.push({name:"AnimeHub",       quality:"HD", langs:["ja","en","hi"],               url:`https://animehub.ac/anime/${slug}/episode-${ep}`});
  return s;
}

// ─── Sort sources by preferred language, then quality ─────────────────────────
function sortSources(sources, prefLang) {
  const qualityScore = {["4K"]:3,["HD"]:2,["SD"]:1};
  return [...sources].sort((a,b) => {
    const aLangMatch = (a.langs||[]).includes(prefLang) ? 1 : 0;
    const bLangMatch = (b.langs||[]).includes(prefLang) ? 1 : 0;
    if(bLangMatch !== aLangMatch) return bLangMatch - aLangMatch;
    return (qualityScore[b.quality]||0) - (qualityScore[a.quality]||0);
  });
}

// ─── NOTE on server selection ──────────────────────────────────────────────
// We can't reliably "ping" third-party embed domains from the browser:
// no-cors fetches return an opaque response even for dead/blocked hosts
// (false positive), while CORS errors fire even for healthy hosts (false
// negative). Instead, PlayerModal loads the first (best-ranked) source
// directly and relies on the iframe's own load/error events plus a
// load-timeout to detect a dead server, automatically advancing to the
// next one in the list. See PlayerModal below.

// ─── Simple in-memory store ───────────────────────────────────────────────────
function useAppStore() {
  const [theme,   setTheme]   = useState("dark");
  const [favs,    setFavs]    = useState(() => { try { return JSON.parse(localStorage.getItem("sv_favs")||"[]"); } catch { return []; }});
  const [history, setHistory] = useState(() => { try { return JSON.parse(localStorage.getItem("sv_hist")||"[]"); } catch { return []; }});
  const [toast,   setToast]   = useState(null);
  const toastTimer = useRef(null);

  const saveToStorage = useCallback((key, val) => { try { localStorage.setItem(key, JSON.stringify(val)); } catch {} }, []);

  const toggleFav = useCallback((item) => {
    setFavs(prev => {
      const exists = prev.find(f=>f.id===item.id);
      const next = exists ? prev.filter(f=>f.id!==item.id) : [...prev, {...item, savedAt:new Date().toISOString()}];
      saveToStorage("sv_favs", next);
      return next;
    });
  },[saveToStorage]);

  const isFav = useCallback((id) => favs.some(f=>f.id===id), [favs]);

  const addHistory = useCallback((item) => {
    setHistory(prev => {
      const filtered = prev.filter(h=>h.id!==item.id);
      const next = [{...item, visitedAt:new Date().toISOString()}, ...filtered].slice(0,60);
      saveToStorage("sv_hist", next);
      return next;
    });
  },[saveToStorage]);

  const clearHistory = useCallback(() => { setHistory([]); saveToStorage("sv_hist",[]); },[saveToStorage]);

  const showToast = useCallback((msg, type="success") => {
    setToast({msg,type});
    clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(()=>setToast(null),3000);
  },[]);

  const toggleTheme = useCallback(()=>setTheme(t=>t==="dark"?"light":"dark"),[]);

  const [prefLang, setPrefLangState] = useState(()=>{ try{return localStorage.getItem("sv_lang")||"en";}catch{return "en";} });
  const setPrefLang = useCallback((l)=>{ setPrefLangState(l); try{localStorage.setItem("sv_lang",l);}catch{} },[]);

  return {theme,toggleTheme,favs,toggleFav,isFav,history,addHistory,clearHistory,toast,showToast,prefLang,setPrefLang};
}

// ─── ICONS (inline SVG subset) ────────────────────────────────────────────────
const I = {
  Home:    ()=><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" width="20" height="20"><path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>,
  Search:  ()=><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" width="20" height="20"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>,
  Heart:   ({fill})=><svg viewBox="0 0 24 24" fill={fill||"none"} stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" width="20" height="20"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>,
  Settings:()=><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" width="20" height="20"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>,
  Play:    ()=><svg viewBox="0 0 24 24" fill="currentColor" width="18" height="18"><polygon points="5 3 19 12 5 21 5 3"/></svg>,
  Back:    ()=><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" width="18" height="18"><polyline points="15 18 9 12 15 6"/></svg>,
  Star:    ()=><svg viewBox="0 0 24 24" fill="currentColor" width="11" height="11"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>,
  X:       ()=><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" width="18" height="18"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>,
  Film:    ()=><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" width="16" height="16"><rect x="2" y="2" width="20" height="20" rx="2.18" ry="2.18"/><line x1="7" y1="2" x2="7" y2="22"/><line x1="17" y1="2" x2="17" y2="22"/><line x1="2" y1="12" x2="22" y2="12"/><line x1="2" y1="7" x2="7" y2="7"/><line x1="2" y1="17" x2="7" y2="17"/><line x1="17" y1="17" x2="22" y2="17"/><line x1="17" y1="7" x2="22" y2="7"/></svg>,
  Tv:      ()=><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" width="16" height="16"><rect x="2" y="7" width="20" height="15" rx="2" ry="2"/><polyline points="17 2 12 7 7 2"/></svg>,
  Sword:   ()=><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" width="16" height="16"><polyline points="14.5 17.5 3 6 3 3 6 3 17.5 14.5"/><line x1="13" y1="19" x2="19" y2="13"/><line x1="16" y1="16" x2="20" y2="20"/><line x1="19" y1="21" x2="21" y2="19"/></svg>,
  Trash:   ()=><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" width="14" height="14"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/></svg>,
  Clock:   ()=><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" width="14" height="14"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>,
  Globe:   ()=><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" width="16" height="16"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>,
  Moon:    ()=><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" width="16" height="16"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>,
  Sun:     ()=><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" width="16" height="16"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>,
  Download:()=><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" width="16" height="16"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>,
  ExternalLink:()=><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" width="12" height="12"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>,
  TrendingUp:()=><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" width="19" height="19"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>,
  Refresh: ()=><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" width="14" height="14"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/></svg>,
  Info:    ()=><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" width="16" height="16"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>,
};

// ─── Spinner ──────────────────────────────────────────────────────────────────
function Spinner({color="var(--accent)",size=38}) {
  return (
    <div style={{width:size,height:size,border:`3px solid var(--border)`,borderTop:`3px solid ${color}`,borderRadius:"50%",animation:"sv-spin 0.8s linear infinite"}} />
  );
}

// ─── Toast ────────────────────────────────────────────────────────────────────
function Toast({toast}) {
  if(!toast) return null;
  const bg = toast.type==="error" ? "var(--red)" : toast.type==="warning" ? "var(--yellow)" : "var(--accent)";
  return (
    <div style={{position:"fixed",bottom:90,left:"50%",transform:"translateX(-50%)",background:bg,color:"#fff",padding:"10px 20px",borderRadius:12,fontWeight:700,fontSize:13,zIndex:9999,boxShadow:"0 4px 20px rgba(0,0,0,0.5)",whiteSpace:"nowrap",animation:"sv-fadeIn 0.2s ease"}}>
      {toast.msg}
    </div>
  );
}

// ─── Bottom Nav ───────────────────────────────────────────────────────────────
const NAV = [
  {id:"home",    icon:I.Home,     label:"Home"},
  {id:"search",  icon:I.Search,   label:"Search"},
  {id:"favs",    icon:I.Heart,    label:"Saved"},
  {id:"settings",icon:I.Settings, label:"Settings"},
];
function BottomNav({page,setPage}) {
  return (
    <nav style={{position:"fixed",bottom:0,left:0,right:0,background:"var(--bg2)",borderTop:"1px solid var(--border)",display:"flex",zIndex:100,paddingBottom:"env(safe-area-inset-bottom,0px)"}}>
      {NAV.map(({id,icon:Icon,label}) => {
        const active = page===id;
        return (
          <button key={id} onClick={()=>setPage(id)} style={{flex:1,display:"flex",flexDirection:"column",alignItems:"center",gap:3,padding:"10px 4px",border:"none",background:"transparent",cursor:"pointer",color:active?"var(--accent)":"var(--text2)",transition:"color 0.2s",WebkitTapHighlightColor:"transparent"}}>
            <Icon />
            <span style={{fontSize:10,fontWeight:active?600:400,letterSpacing:"0.02em"}}>{label}</span>
          </button>
        );
      })}
    </nav>
  );
}

// ─── Poster Card ──────────────────────────────────────────────────────────────
function PosterCard({item, onTap, width=100}) {
  const isAnime = item._type==="anime";
  const title = isAnime ? (item.title?.english||item.title?.romaji||"?") : (item.title||item.name||"?");
  const poster = isAnime ? item.coverImage?.large : posterUrl(item.poster_path,"w185");
  const rating = isAnime ? (item.averageScore?(item.averageScore/10).toFixed(1):null) : (item.vote_average?item.vote_average.toFixed(1):null);
  return (
    <div onClick={()=>onTap(item)} style={{flexShrink:0,width,cursor:"pointer"}}>
      <div style={{position:"relative",marginBottom:6}}>
        {poster
          ? <img src={poster} alt={title} loading="lazy" style={{width,height:Math.round(width*1.45),borderRadius:12,objectFit:"cover",background:"var(--bg3)",display:"block"}} />
          : <div style={{width,height:Math.round(width*1.45),borderRadius:12,background:"var(--bg3)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:28}}>🎬</div>
        }
        {rating && <div style={{position:"absolute",bottom:5,left:5,background:"rgba(0,0,0,0.85)",borderRadius:6,padding:"2px 6px",display:"flex",alignItems:"center",gap:2,fontSize:10,fontWeight:800,color:"var(--yellow)"}}><I.Star />{rating}</div>}
      </div>
      <div style={{fontSize:11,fontWeight:700,lineHeight:1.3,overflow:"hidden",display:"-webkit-box",WebkitLineClamp:2,WebkitBoxOrient:"vertical"}}>{title}</div>
    </div>
  );
}

// ─── Horizontal Row ───────────────────────────────────────────────────────────
function HRow({title, icon:Icon, color, items, onTap}) {
  return (
    <div style={{padding:"0 0 0 20px"}}>
      <div style={{display:"flex",alignItems:"center",gap:8,paddingRight:20,marginBottom:12}}>
        <Icon />
        <span style={{fontSize:15,fontWeight:800}}>{title}</span>
      </div>
      <div style={{display:"flex",gap:10,overflowX:"auto",paddingRight:20,paddingBottom:6,scrollbarWidth:"none"}}>
        {items.map((item,i)=><PosterCard key={`${item._type}-${item.id}-${i}`} item={item} onTap={onTap} />)}
      </div>
    </div>
  );
}

// ─── Player Modal ─────────────────────────────────────────────────────────────
function PlayerModal({title, sources, srcIdx, setSrcIdx, onClose, prefLang}) {
  const [loadState, setLoadState] = useState("loading"); // loading | ok | failed
  const [langOverride, setLangOverride] = useState(prefLang || null);
  const [failedIdx, setFailedIdx] = useState(() => new Set());
  const [popupsBlocked, setPopupsBlocked] = useState(0);
  const timeoutRef = useRef(null);

  const rawCurr = sources[srcIdx];
  const curr = withLang(rawCurr, langOverride);

  // ─── Pop-up / new-tab ad blocker ─────────────────────────────────────────
  // Many free embed players open ad tabs via window.open() (or a renamed
  // alias) the moment the iframe loads or on first click. We can't reach
  // inside the iframe (cross-origin), but we CAN stop *our own* window from
  // spawning the new tab/window the ad script asks for, since that call
  // bubbles up to this top-level window object.
  useEffect(()=>{
    const realOpen = window.open;
    window.open = function(...args){
      setPopupsBlocked(n=>n+1);
      return null; // pretend the popup opened, then do nothing
    };
    return ()=>{ window.open = realOpen; };
  },[]);

  // When the active source changes, (re)start the load watchdog.
  useEffect(()=>{
    if(!rawCurr) return;
    setLoadState("loading");
    if(timeoutRef.current) clearTimeout(timeoutRef.current);
    // If the iframe hasn't fired onLoad within 9s, treat as a dead server
    // and auto-advance to the next one.
    timeoutRef.current = setTimeout(()=>{
      setLoadState(prev => {
        if(prev === "loading") {
          advanceToNext();
          return "failed";
        }
        return prev;
      });
    }, 9000);
    return ()=>{ if(timeoutRef.current) clearTimeout(timeoutRef.current); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  },[srcIdx, rawCurr?.url]);

  const advanceToNext = useCallback(()=>{
    setFailedIdx(prev => {
      const next = new Set(prev);
      next.add(srcIdx);
      // find next index not yet marked failed
      for(let i=1; i<=sources.length; i++){
        const candidate = (srcIdx + i) % sources.length;
        if(!next.has(candidate)){
          setSrcIdx(candidate);
          break;
        }
      }
      return next;
    });
  },[srcIdx, sources, setSrcIdx]);

  if(!curr) return null;

  // All unique languages across all sources
  const allLangs = [...new Set(sources.flatMap(s=>s.langs||[]))];
  const allFailed = failedIdx.size >= sources.length;

  return (
    <div style={{position:"fixed",inset:0,background:"#000",zIndex:500,display:"flex",flexDirection:"column",animation:"sv-fadeIn 0.2s ease"}}>
      {/* Header */}
      <div style={{padding:"10px 14px",display:"flex",alignItems:"center",justifyContent:"space-between",borderBottom:"1px solid #1a1a1a",background:"#080810"}}>
        <div style={{flex:1,minWidth:0}}>
          <div style={{fontWeight:700,fontSize:13,color:"#fff",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{title}</div>
          <div style={{fontSize:11,color:"#777",marginTop:1,display:"flex",alignItems:"center",gap:6}}>
            {loadState==="loading"
              ? <span style={{color:"var(--accent)"}}>⚡ Loading {curr.name}…</span>
              : loadState==="failed"
                ? <span style={{color:"var(--red)"}}>✕ {curr.name} failed — switching…</span>
                : <><span style={{color:"var(--green)"}}>✓ {curr.name}</span><span>·</span><span>{curr.quality}</span>{curr.langs&&<span>· {curr.langs.slice(0,3).map(l=>LANGS[l]?.split(" ")[0]).join(" ")}</span>}{curr.langParam && langOverride && (curr.langs||[]).includes(langOverride) && <span style={{color:"var(--accent)"}}>· 🌐 {LANGS[langOverride]?.split(" ")[0]}</span>}</>
            }
          </div>
        </div>
        {popupsBlocked>0 && (
          <div style={{fontSize:10,color:"var(--green)",background:"#1a2e1a",border:"1px solid #2a4a2a",borderRadius:99,padding:"3px 8px",marginRight:8,whiteSpace:"nowrap",flexShrink:0}}>
            🛡️ {popupsBlocked} ad{popupsBlocked>1?"s":""} blocked
          </div>
        )}
        <button onClick={onClose} style={{background:"#1a1a1a",border:"none",borderRadius:99,width:34,height:34,display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer",color:"#fff",marginLeft:10,flexShrink:0}}>
          <I.X />
        </button>
      </div>

      {/* iFrame */}
      <div style={{flex:1,position:"relative",minHeight:0}}>
        {loadState==="loading" && (
          <div style={{position:"absolute",inset:0,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",gap:14,background:"#000",zIndex:10}}>
            <div style={{width:48,height:48,border:"3px solid #222",borderTop:"3px solid var(--accent)",borderRadius:"50%",animation:"sv-spin 0.8s linear infinite"}} />
            <div style={{color:"#888",fontSize:13}}>Loading {curr.name}…</div>
          </div>
        )}
        {allFailed ? (
          <div style={{position:"absolute",inset:0,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",gap:10,background:"#000",padding:20,textAlign:"center"}}>
            <div style={{color:"var(--red)",fontSize:36}}><I.X/></div>
            <div style={{color:"#fff",fontSize:14,fontWeight:700}}>All servers failed to load</div>
            <div style={{color:"#888",fontSize:12,maxWidth:280}}>This can happen if your network blocks these streaming domains, or they're temporarily down. Try again later or switch networks.</div>
            <button onClick={()=>{setFailedIdx(new Set()); setSrcIdx(0);}} style={{marginTop:8,padding:"8px 16px",borderRadius:8,border:"1px solid var(--accent)",background:"var(--accent)22",color:"var(--accent)",fontSize:12,fontWeight:700,cursor:"pointer"}}>
              Retry all servers
            </button>
          </div>
        ) : (
          <iframe
            key={`${srcIdx}-${curr.url}`}
            src={curr.url}
            style={{width:"100%",height:"100%",border:"none"}}
            allowFullScreen
            allow="fullscreen;autoplay;encrypted-media;picture-in-picture"
            referrerPolicy="no-referrer"
            title={title}
            onLoad={()=>{
              if(timeoutRef.current) clearTimeout(timeoutRef.current);
              setLoadState("ok");
            }}
            onError={()=>{
              if(timeoutRef.current) clearTimeout(timeoutRef.current);
              setLoadState("failed");
              advanceToNext();
            }}
          />
        )}
      </div>

      {/* Bottom Controls */}
      <div style={{background:"#080810",borderTop:"1px solid #1a1a1a",padding:"8px 14px 10px"}}>
        {/* Language Selector */}
        <div style={{marginBottom:8}}>
          <div style={{fontSize:10,color:"#444",fontWeight:700,textTransform:"uppercase",letterSpacing:"0.08em",marginBottom:5}}>
            Audio / Subtitle Language
          </div>
          <div style={{display:"flex",gap:5,overflowX:"auto",scrollbarWidth:"none",paddingBottom:2}}>
            <button onClick={()=>setLangOverride(null)} style={{flexShrink:0,padding:"4px 10px",borderRadius:99,border:"1px solid",borderColor:langOverride===null?"var(--accent)":"#2a2a2a",background:langOverride===null?"var(--accent)22":"#111",color:langOverride===null?"var(--accent)":"#666",fontSize:11,cursor:"pointer",whiteSpace:"nowrap",fontWeight:langOverride===null?700:400}}>
              Default
            </button>
            {allLangs.map(l=>{
              const active = langOverride===l;
              // Does the *current* server actually apply this language live?
              const liveOnCurrent = !!rawCurr?.langParam && (rawCurr.langs||[]).includes(l);
              return (
                <button key={l} onClick={()=>{
                  setLangOverride(l===langOverride?null:l);
                  // If the current server doesn't support this language at all,
                  // jump to the first server that supports it (prefer one with langParam).
                  if(!(rawCurr?.langs||[]).includes(l)){
                    const withParam = sources.findIndex(s=>(s.langs||[]).includes(l) && s.langParam);
                    const any = sources.findIndex(s=>(s.langs||[]).includes(l));
                    const target = withParam>=0 ? withParam : any;
                    if(target>=0) setSrcIdx(target);
                  }
                }} title={liveOnCurrent ? "Switches audio/subtitles on this server" : "Will switch to a server offering this language"} style={{flexShrink:0,padding:"4px 10px",borderRadius:99,border:"1px solid",borderColor:active?"#f59e0b":"#2a2a2a",background:active?"#f59e0b22":"#111",color:active?"#f59e0b":"#666",fontSize:11,cursor:"pointer",whiteSpace:"nowrap",fontWeight:active?700:400}}>
                  {LANGS[l]||l}{active && liveOnCurrent ? " ✓" : ""}
                </button>
              );
            })}
          </div>
          {langOverride && !rawCurr?.langParam && (
            <div style={{fontSize:10,color:"var(--text2)",marginTop:5}}>
              {curr.name} doesn't support in-player language switching — pick a 🌐 marked server below for live switching, or this just changed which server is loaded.
            </div>
          )}
        </div>

        {/* Server switcher */}
        <div>
          <div style={{fontSize:10,color:"#444",fontWeight:700,textTransform:"uppercase",letterSpacing:"0.08em",marginBottom:5}}>
            Servers ({sources.length})
          </div>
          <div style={{display:"flex",gap:5,overflowX:"auto",scrollbarWidth:"none",paddingBottom:2}}>
            {sources.map((s,i)=>{
              const isActive = i===srcIdx;
              const isFailed = failedIdx.has(i);
              return (
                <button key={i} onClick={()=>{ if(isFailed){setFailedIdx(prev=>{const n=new Set(prev); n.delete(i); return n;});} setSrcIdx(i); }} style={{flexShrink:0,padding:"4px 10px",borderRadius:99,border:"1px solid",borderColor:isActive?"var(--accent)":isFailed?"var(--red)":"#2a2a2a",background:isActive?"var(--accent)22":isFailed?"var(--red)11":"#111",color:isActive?"var(--accent)":isFailed?"var(--red)":"#888",fontWeight:isActive?700:400,fontSize:11,cursor:"pointer",whiteSpace:"nowrap",opacity:isFailed&&!isActive?0.6:1}}>
                  {s.name}
                  {s.langParam && <span style={{fontSize:9,marginLeft:3}}>🌐</span>}
                  <span style={{fontSize:9,marginLeft:4,color:s.quality==="4K"?"#a855f7":s.quality==="HD"?"var(--green)":"#666"}}>{s.quality}</span>
                  {isFailed && <span style={{fontSize:9,marginLeft:3}}>✕</span>}
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── HOME PAGE ────────────────────────────────────────────────────────────────
function HomePage({setPage, setDetail, favs, history}) {
  const [movies,    setMovies]    = useState([]);
  const [tv,        setTV]        = useState([]);
  const [anime,     setAnime]     = useState([]);
  const [topMovies, setTopMovies] = useState([]);
  const [nowPlay,   setNowPlay]   = useState([]);

  useEffect(()=>{
    getTrendingMovies().then(d=>setMovies(d.slice(0,15))).catch(()=>{});
    getTrendingTV().then(d=>setTV(d.slice(0,15))).catch(()=>{});
    getTrendingAnime().then(d=>setAnime(d.slice(0,15))).catch(()=>{});
    getTopRatedMovies().then(d=>setTopMovies(d.slice(0,15))).catch(()=>{});
    getNowPlaying().then(d=>setNowPlay(d.slice(0,15))).catch(()=>{});
  },[]);

  const nav = (item) => {
    if(item._type==="anime")  setDetail({type:"anime",  id:item.id});
    else if(item._type==="tv")setDetail({type:"tv",     id:item.id});
    else                      setDetail({type:"movie",  id:item.id});
  };

  const loading = movies.length===0&&tv.length===0&&anime.length===0;

  return (
    <div style={{paddingBottom:24}}>
      {/* Hero Header */}
      <div style={{padding:"20px 20px 16px",background:"var(--bg2)",borderBottom:"1px solid var(--border)",marginBottom:8}}>
        <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:14}}>
          <div style={{display:"flex",alignItems:"center",gap:10}}>
            <div style={{width:40,height:40,borderRadius:14,background:"linear-gradient(135deg,#7c6aff,#a855f7)",display:"flex",alignItems:"center",justifyContent:"center"}}>
              <I.TrendingUp />
            </div>
            <div>
              <div style={{fontSize:22,fontWeight:800,letterSpacing:"-0.5px"}}>StreamVault</div>
              <div style={{fontSize:11,color:"var(--text2)"}}>Movies · TV · Anime · Free</div>
            </div>
          </div>
          <button onClick={()=>setPage("search")} style={{background:"var(--bg3)",border:"1px solid var(--border)",borderRadius:12,padding:"9px 14px",display:"flex",alignItems:"center",gap:6,color:"var(--text2)",cursor:"pointer",fontSize:13,fontWeight:600}}>
            <I.Search /> Search
          </button>
        </div>
        {/* Stats */}
        <div style={{display:"flex",gap:8}}>
          {[
            {label:"Movies",   value:movies.length||"…",  color:"var(--accent)"},
            {label:"TV Shows", value:tv.length||"…",      color:"var(--cyan)"},
            {label:"Anime",    value:anime.length||"…",   color:"var(--yellow)"},
            {label:"Saved",    value:favs.length,          color:"#ec4899"},
          ].map(({label,value,color})=>(
            <div key={label} style={{flex:1,padding:"10px 4px",background:"var(--bg3)",border:"1px solid var(--border)",borderRadius:12,textAlign:"center"}}>
              <div style={{fontSize:16,fontWeight:800,color}}>{value}</div>
              <div style={{fontSize:10,color:"var(--text2)",marginTop:1}}>{label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Continue Watching */}
      {history.length>0 && (
        <div style={{padding:"12px 20px 0"}}>
          <div style={{display:"flex",alignItems:"center",gap:6,marginBottom:10}}>
            <I.Clock />
            <span style={{fontSize:14,fontWeight:800}}>Continue Watching</span>
          </div>
          <div style={{display:"flex",gap:8,overflowX:"auto",scrollbarWidth:"none"}}>
            {history.slice(0,8).map((item,i)=>(
              <div key={i} onClick={()=>{
                const id=item.id||"";
                if(id.startsWith("anime-")) setDetail({type:"anime",id:id.replace("anime-","")});
                else if(id.startsWith("tv-")) setDetail({type:"tv",id:id.replace("tv-","")});
                else setDetail({type:"movie",id:id.replace("movie-","")});
              }} style={{flexShrink:0,cursor:"pointer",width:70}}>
                {item.poster
                  ? <img src={item.poster} style={{width:70,height:100,borderRadius:10,objectFit:"cover",display:"block",background:"var(--bg3)"}} loading="lazy" alt={item.title||""} />
                  : <div style={{width:70,height:100,borderRadius:10,background:"var(--bg3)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:24}}>🎬</div>
                }
                <div style={{fontSize:10,fontWeight:600,marginTop:4,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{typeof item.title==="object"?(item.title?.english||item.title?.romaji||"?"):(item.title||"?")}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {loading ? (
        <div style={{display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",height:"40vh",gap:16}}>
          <Spinner />
          <div style={{fontSize:13,color:"var(--text2)"}}>Loading content…</div>
        </div>
      ) : (
        <div style={{display:"flex",flexDirection:"column",gap:22,marginTop:20}}>
          {movies.length>0   && <HRow title="Trending Movies"   icon={I.Film}  color="var(--accent)" items={movies.map(m=>({...m,_type:"movie"}))}   onTap={nav} />}
          {tv.length>0       && <HRow title="Trending TV Shows"  icon={I.Tv}    color="var(--cyan)"   items={tv.map(t=>({...t,_type:"tv"}))}          onTap={nav} />}
          {anime.length>0    && <HRow title="Trending Anime"     icon={I.Sword} color="var(--yellow)" items={anime.map(a=>({...a,_type:"anime"}))}    onTap={nav} />}
          {topMovies.length>0&& <HRow title="Top Rated Movies"   icon={I.Star}  color="var(--green)"  items={topMovies.map(m=>({...m,_type:"movie"}))} onTap={nav} />}
          {nowPlay.length>0  && <HRow title="Now In Theatres"    icon={I.Film}  color="#ec4899"       items={nowPlay.map(m=>({...m,_type:"movie"}))}   onTap={nav} />}
        </div>
      )}
    </div>
  );
}

// ─── SEARCH PAGE ──────────────────────────────────────────────────────────────
function SearchPage({setDetail}) {
  const [query,   setQuery]   = useState("");
  const [tab,     setTab]     = useState("all");
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searched,setSearched]= useState(false);
  const timer = useRef(null);

  const doSearch = useCallback(async(q, t)=>{
    if(!q.trim()){setResults([]);setSearched(false);return;}
    setLoading(true);setSearched(true);
    try{
      let data=[];
      if(t==="anime"){
        data=(await searchAnime(q)).map(a=>({...a,_type:"anime"}));
      }else if(t==="movie"){
        data=(await searchAll(q)).filter(x=>x.media_type==="movie").map(x=>({...x,_type:"movie"}));
      }else if(t==="tv"){
        data=(await searchAll(q)).filter(x=>x.media_type==="tv").map(x=>({...x,_type:"tv"}));
      }else{
        const [tmdbRes,alRes]=await Promise.all([searchAll(q),searchAnime(q)]);
        data=[
          ...tmdbRes.filter(x=>x.media_type==="movie").map(x=>({...x,_type:"movie"})),
          ...tmdbRes.filter(x=>x.media_type==="tv").map(x=>({...x,_type:"tv"})),
          ...alRes.slice(0,6).map(a=>({...a,_type:"anime"})),
        ];
      }
      setResults(data);
    }catch{}
    setLoading(false);
  },[]);

  useEffect(()=>{
    clearTimeout(timer.current);
    timer.current=setTimeout(()=>{if(query.length>=2)doSearch(query,tab);},480);
    return()=>clearTimeout(timer.current);
  },[query,tab]);

  const open=(item)=>{
    if(item._type==="anime") setDetail({type:"anime",id:item.id});
    else if(item._type==="tv") setDetail({type:"tv",id:item.id});
    else setDetail({type:"movie",id:item.id});
  };
  const getTitle=i=>{const t=i.title||i.name;return typeof t==="object"?(t?.english||t?.romaji||"?"):(t||"?");};
  const getPoster=i=>i._type==="anime"?i.coverImage?.large:posterUrl(i.poster_path,"w185");
  const getRating=i=>i._type==="anime"?(i.averageScore?(i.averageScore/10).toFixed(1):null):(i.vote_average?i.vote_average.toFixed(1):null);

  const TABS=[{key:"all",label:"All"},{key:"movie",label:"Movies"},{key:"tv",label:"TV"},{key:"anime",label:"Anime"}];
  const TYPE_COLOR={movie:"var(--accent)",tv:"var(--cyan)",anime:"var(--yellow)"};

  return (
    <div style={{paddingBottom:24}}>
      {/* Search bar */}
      <div style={{padding:"16px 20px",background:"var(--bg2)",borderBottom:"1px solid var(--border)"}}>
        <div style={{position:"relative"}}>
          <div style={{position:"absolute",left:12,top:"50%",transform:"translateY(-50%)",color:"var(--text2)",pointerEvents:"none"}}>
            <I.Search />
          </div>
          <input
            value={query} onChange={e=>setQuery(e.target.value)}
            placeholder="Movies, shows, anime…"
            autoFocus
            style={{width:"100%",boxSizing:"border-box",padding:"12px 12px 12px 42px",background:"var(--bg3)",border:"1px solid var(--border)",borderRadius:14,color:"var(--text)",fontSize:15,outline:"none",fontFamily:"inherit"}}
          />
          {query && <button onClick={()=>{setQuery("");setResults([]);setSearched(false);}} style={{position:"absolute",right:12,top:"50%",transform:"translateY(-50%)",background:"none",border:"none",cursor:"pointer",color:"var(--text2)"}}><I.X /></button>}
        </div>
        {/* Tabs */}
        <div style={{display:"flex",gap:6,marginTop:12}}>
          {TABS.map(t=>(
            <button key={t.key} onClick={()=>setTab(t.key)} style={{flex:1,padding:"8px 4px",borderRadius:10,border:"1px solid",borderColor:tab===t.key?"var(--accent)":"var(--border)",background:tab===t.key?"var(--accent)22":"var(--bg3)",color:tab===t.key?"var(--accent)":"var(--text2)",fontWeight:tab===t.key?700:500,fontSize:12,cursor:"pointer"}}>
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {loading && <div style={{display:"flex",justifyContent:"center",padding:40}}><Spinner /></div>}

      {!loading && searched && results.length===0 && (
        <div style={{display:"flex",flexDirection:"column",alignItems:"center",padding:60,gap:12,color:"var(--text2)"}}>
          <div style={{fontSize:40}}>🔍</div>
          <div style={{fontWeight:700,fontSize:16}}>No results found</div>
          <div style={{fontSize:13}}>Try a different search term</div>
        </div>
      )}

      {!loading && !searched && (
        <div style={{display:"flex",flexDirection:"column",alignItems:"center",padding:60,gap:12,color:"var(--text2)"}}>
          <div style={{fontSize:40}}>🎬</div>
          <div style={{fontWeight:700,fontSize:16}}>Search anything</div>
          <div style={{fontSize:13}}>Movies, TV shows, or anime</div>
        </div>
      )}

      {!loading && results.length>0 && (
        <div style={{padding:"12px 20px",display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:12}}>
          {results.map((item,i)=>{
            const title=getTitle(item);
            const poster=getPoster(item);
            const rating=getRating(item);
            const color=TYPE_COLOR[item._type]||"var(--accent)";
            return (
              <div key={`${item._type}-${item.id}-${i}`} onClick={()=>open(item)} style={{cursor:"pointer"}}>
                <div style={{position:"relative",marginBottom:6}}>
                  {poster
                    ?<img src={poster} alt={title} loading="lazy" style={{width:"100%",aspectRatio:"2/3",borderRadius:12,objectFit:"cover",background:"var(--bg3)",display:"block"}} />
                    :<div style={{width:"100%",aspectRatio:"2/3",borderRadius:12,background:"var(--bg3)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:28}}>🎬</div>
                  }
                  {rating && <div style={{position:"absolute",bottom:5,left:5,background:"rgba(0,0,0,0.85)",borderRadius:6,padding:"2px 6px",display:"flex",alignItems:"center",gap:2,fontSize:10,fontWeight:800,color:"var(--yellow)"}}><I.Star />{rating}</div>}
                  <div style={{position:"absolute",top:5,right:5,background:"rgba(0,0,0,0.8)",borderRadius:6,padding:"2px 6px",fontSize:9,fontWeight:700,color,textTransform:"uppercase"}}>{item._type}</div>
                </div>
                <div style={{fontSize:11,fontWeight:700,lineHeight:1.3,overflow:"hidden",display:"-webkit-box",WebkitLineClamp:2,WebkitBoxOrient:"vertical"}}>{title}</div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

// ─── FAVORITES PAGE ───────────────────────────────────────────────────────────
function FavoritesPage({favs, toggleFav, showToast, setDetail, setPage}) {
  const getPath=(item)=>{
    if(item.id.startsWith("anime-")) return {type:"anime",id:item.id.replace("anime-","")};
    if(item.id.startsWith("tv-"))    return {type:"tv",id:item.id.replace("tv-","")};
    return {type:"movie",id:item.id.replace("movie-","")};
  };
  const getTypeColor=(item)=>{
    if(item.id.startsWith("anime-")) return "var(--yellow)";
    if(item.id.startsWith("tv-"))    return "var(--cyan)";
    return "var(--accent)";
  };

  return (
    <div style={{paddingBottom:24}}>
      <div style={{padding:"20px 20px 16px",background:"var(--bg2)",borderBottom:"1px solid var(--border)"}}>
        <div style={{fontSize:20,fontWeight:800}}>Saved</div>
        <div style={{fontSize:12,color:"var(--text2)",marginTop:2}}>{favs.length} {favs.length===1?"item":"items"}</div>
      </div>
      {favs.length===0 ? (
        <div style={{display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",height:"50vh",gap:16,color:"var(--text2)"}}>
          <div style={{fontSize:52}}>💙</div>
          <div style={{fontWeight:700,fontSize:18}}>Nothing saved yet</div>
          <div style={{fontSize:13,textAlign:"center",maxWidth:220,lineHeight:1.5}}>Tap the heart on any movie, show or anime to save it here</div>
          <button onClick={()=>setPage("search")} style={{marginTop:8,padding:"10px 24px",borderRadius:12,border:"none",background:"var(--accent)",color:"#fff",fontWeight:700,cursor:"pointer",fontSize:14}}>Browse Content</button>
        </div>
      ) : (
        <div style={{padding:"16px 20px",display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:12}}>
          {favs.map(item=>{
            const title=typeof item.title==="object"?(item.title?.english||item.title?.romaji||"?"):(item.title||"?");
            const color=getTypeColor(item);
            return (
              <div key={item.id} style={{position:"relative"}}>
                <div onClick={()=>setDetail(getPath(item))} style={{cursor:"pointer"}}>
                  {item.poster
                    ?<img src={item.poster} alt={title} loading="lazy" style={{width:"100%",aspectRatio:"2/3",borderRadius:12,objectFit:"cover",display:"block",background:"var(--bg3)"}} />
                    :<div style={{width:"100%",aspectRatio:"2/3",borderRadius:12,background:"var(--bg3)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:32}}>🎬</div>
                  }
                  <div style={{marginTop:6}}>
                    <div style={{fontSize:11,fontWeight:700,lineHeight:1.3,overflow:"hidden",display:"-webkit-box",WebkitLineClamp:2,WebkitBoxOrient:"vertical"}}>{title}</div>
                    <div style={{fontSize:10,color,marginTop:2}}>{item._repoName||item.id.split("-")[0]}</div>
                  </div>
                </div>
                <button onClick={()=>{toggleFav(item);showToast("Removed from saved");}} style={{position:"absolute",top:6,right:6,background:"rgba(0,0,0,0.75)",border:"none",borderRadius:99,width:28,height:28,display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer",color:"var(--red)"}}>
                  <I.Trash />
                </button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

// ─── SETTINGS PAGE ────────────────────────────────────────────────────────────
function SettingsPage({theme,toggleTheme,favs,history,clearHistory,showToast,prefLang,setPrefLang}) {
  const handleExport=()=>{
    const data={favs,exportedAt:new Date().toISOString(),version:"2.0"};
    const blob=new Blob([JSON.stringify(data,null,2)],{type:"application/json"});
    const url=URL.createObjectURL(blob);
    const a=document.createElement("a");a.href=url;a.download="streamvault-backup.json";a.click();
    URL.revokeObjectURL(url);
    showToast("Backup exported!");
  };

  const Section=({title,children})=>(
    <div style={{marginBottom:20}}>
      <div style={{fontSize:11,color:"var(--text2)",fontWeight:700,textTransform:"uppercase",letterSpacing:"0.08em",padding:"0 20px",marginBottom:8}}>{title}</div>
      <div style={{background:"var(--bg2)",border:"1px solid var(--border)",borderRadius:16,overflow:"hidden",margin:"0 20px"}}>{children}</div>
    </div>
  );
  const Row=({icon:Icon,label,value,onClick,color,last})=>(
    <button onClick={onClick||undefined} style={{width:"100%",display:"flex",alignItems:"center",gap:14,padding:"14px 16px",background:"transparent",border:"none",borderBottom:last?"none":"1px solid var(--border)",cursor:onClick?"pointer":"default",textAlign:"left"}}>
      <div style={{width:32,height:32,borderRadius:9,background:(color||"var(--accent)")+"22",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
        <span style={{color:color||"var(--accent)"}}><Icon /></span>
      </div>
      <div style={{flex:1}}>
        <div style={{fontSize:14,fontWeight:600,color:"var(--text)"}}>{label}</div>
        {value&&<div style={{fontSize:12,color:"var(--text2)",marginTop:2}}>{value}</div>}
      </div>
    </button>
  );

  return (
    <div style={{paddingBottom:40}}>
      <div style={{padding:"20px 20px 16px",background:"var(--bg2)",borderBottom:"1px solid var(--border)",marginBottom:20}}>
        <div style={{fontSize:20,fontWeight:800}}>Settings</div>
        <div style={{fontSize:12,color:"var(--text2)",marginTop:2}}>Customize StreamVault</div>
      </div>
      <Section title="Appearance">
        <Row icon={theme==="dark"?I.Moon:I.Sun} label="Theme" value={theme==="dark"?"Dark mode":"Light mode"} color={theme==="dark"?"var(--accent)":"var(--yellow)"} onClick={toggleTheme} last />
      </Section>
      <Section title="Data">
        <Row icon={I.Heart} label="Saved Favorites" value={`${favs.length} items`} color="#ec4899" />
        <Row icon={I.Clock} label="Watch History"  value={`${history.length} items`} color="var(--accent)" />
        <Row icon={I.Trash} label="Clear History"  value="Remove all watch history" color="var(--red)" onClick={()=>{clearHistory();showToast("History cleared");}} last />
      </Section>
      <Section title="Backup">
        <Row icon={I.Download} label="Export Backup" value="Download favorites as JSON" color="var(--green)" onClick={handleExport} last />
      </Section>
      <Section title="Audio Language">
        <div style={{padding:"12px 16px",borderBottom:"1px solid var(--border)"}}>
          <div style={{fontSize:13,fontWeight:600,color:"var(--text)",marginBottom:10}}>Preferred Audio</div>
          <div style={{display:"flex",flexWrap:"wrap",gap:6}}>
            {Object.entries(LANGS).map(([code,label])=>{
              const active = prefLang===code;
              return (
                <button key={code} onClick={()=>setPrefLang(code)} style={{padding:"6px 12px",borderRadius:99,border:"1px solid",borderColor:active?"var(--accent)":"var(--border)",background:active?"var(--accent)22":"var(--bg3)",color:active?"var(--accent)":"var(--text2)",fontWeight:active?700:400,fontSize:12,cursor:"pointer",whiteSpace:"nowrap"}}>
                  {label}
                </button>
              );
            })}
          </div>
          <div style={{fontSize:11,color:"var(--text2)",marginTop:10}}>Servers that support your preferred language are shown first. Servers marked 🌐 in the player can switch audio/subtitles to this language live; others will switch to a different server instead.</div>
        </div>
      </Section>
      <Section title="Streaming Sources">
        <Row icon={I.Globe} label="VidSrc Suite" value="vidsrc.to · vidsrc.xyz · vidsrc.me" color="var(--accent)" />
        <Row icon={I.Globe} label="Embed Providers" value="embed.su · multiembed.mov · 2embed" color="var(--cyan)" />
        <Row icon={I.Globe} label="Anime" value="gogoanime · hianime · 9animetv" color="var(--yellow)" />
        <Row icon={I.Globe} label="Metadata" value="TMDB · AniList GraphQL" color="var(--green)" last />
      </Section>
      <Section title="About">
        <Row icon={I.Info} label="StreamVault" value="v2.0 · Free · All-in-one streaming app" color="var(--accent)" last />
      </Section>
    </div>
  );
}

// ─── MOVIE DETAIL PAGE ────────────────────────────────────────────────────────
function MovieDetail({id, store, onBack}) {
  const {toggleFav,isFav,addHistory,showToast}=store;
  const [movie,   setMovie]   = useState(null);
  const [loading, setLoading] = useState(true);
  const [tab,     setTab]     = useState("about");
  const [showPlayer,setPlayer]= useState(false);
  const [sources, setSources] = useState([]);
  const [srcIdx,  setSrcIdx]  = useState(0);
  const [related, setRelated] = useState([]);

  useEffect(()=>{
    setLoading(true);setMovie(null);setRelated([]);setTab("about");
    getMovieDetail(Number(id))
      .then(data=>{
        setMovie(data);
        addHistory({id:`movie-${data.id}`,title:data.title,_repoName:"Movies",poster:posterUrl(data.poster_path)});
        setSources(sortSources(getMovieSources(data.id,data.imdb_id), store.prefLang));
        if(data.similar?.length) setRelated(data.similar.slice(0,12));
      })
      .catch(()=>showToast("Failed to load movie","error"))
      .finally(()=>setLoading(false));
  },[id]);

  if(loading) return <div style={{display:"flex",alignItems:"center",justifyContent:"center",height:"80vh",flexDirection:"column",gap:16}}><Spinner /></div>;
  if(!movie)  return <div style={{padding:40,textAlign:"center",color:"var(--text2)"}}>Movie not found. <button onClick={onBack} style={{color:"var(--accent)",background:"none",border:"none",cursor:"pointer"}}>Go back</button></div>;

  const fav={id:`movie-${movie.id}`,title:movie.title,_repoName:"Movies",poster:posterUrl(movie.poster_path)};
  const rating=movie.vote_average?.toFixed(1);
  const cast=(movie.credits?.cast||[]).slice(0,12);
  const dir=movie.credits?.crew?.find(c=>c.job==="Director");
  const trailer=movie.videos?.find(v=>v.type==="Trailer"&&v.site==="YouTube");

  return (
    <div style={{paddingBottom:24,animation:"sv-fadeIn 0.2s ease"}}>
      <button onClick={onBack} style={{position:"fixed",top:16,left:16,zIndex:200,background:"rgba(0,0,0,0.75)",border:"none",borderRadius:99,padding:"8px 14px",color:"#fff",cursor:"pointer",display:"flex",alignItems:"center",gap:6,fontWeight:700,fontSize:13,backdropFilter:"blur(10px)"}}>
        <I.Back /> Back
      </button>

      {/* Backdrop */}
      <div style={{position:"relative",height:250,background:"var(--bg3)"}}>
        {backdropUrl(movie.backdrop_path)&&<img src={backdropUrl(movie.backdrop_path)} alt="" style={{width:"100%",height:"100%",objectFit:"cover"}} />}
        <div style={{position:"absolute",inset:0,background:"linear-gradient(to bottom,rgba(0,0,0,0.1) 0%,var(--bg) 100%)"}} />
        {trailer&&<a href={`https://youtube.com/watch?v=${trailer.key}`} target="_blank" rel="noopener noreferrer" style={{position:"absolute",top:"50%",left:"50%",transform:"translate(-50%,-50%)",background:"rgba(255,255,255,0.15)",border:"2px solid rgba(255,255,255,0.8)",borderRadius:99,padding:"10px 20px",color:"#fff",fontWeight:700,fontSize:13,cursor:"pointer",display:"flex",alignItems:"center",gap:8,backdropFilter:"blur(10px)",textDecoration:"none"}}>▶ Trailer</a>}
      </div>

      <div style={{padding:"0 20px",marginTop:-60,position:"relative"}}>
        <div style={{display:"flex",gap:16,alignItems:"flex-end"}}>
          {posterUrl(movie.poster_path,"w342")
            ?<img src={posterUrl(movie.poster_path,"w342")} alt={movie.title} style={{width:110,height:160,borderRadius:14,objectFit:"cover",border:"3px solid var(--bg)",flexShrink:0,boxShadow:"0 8px 32px rgba(0,0,0,0.5)"}} />
            :<div style={{width:110,height:160,borderRadius:14,background:"var(--bg3)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:36,flexShrink:0}}>🎬</div>
          }
          <div style={{flex:1,paddingBottom:4,minWidth:0}}>
            <h1 style={{fontSize:18,fontWeight:800,lineHeight:1.2,marginBottom:8,marginTop:0}}>{movie.title}</h1>
            <div style={{display:"flex",gap:6,flexWrap:"wrap",marginBottom:10}}>
              {rating&&<span style={{display:"flex",alignItems:"center",gap:3,fontSize:12,padding:"3px 8px",borderRadius:99,background:"var(--yellow)22",color:"var(--yellow)",fontWeight:800,border:"1px solid var(--yellow)44"}}><I.Star />{rating}</span>}
              {movie.release_date&&<span style={{fontSize:12,padding:"3px 8px",borderRadius:99,background:"var(--bg3)",color:"var(--text2)",border:"1px solid var(--border)"}}>{movie.release_date.slice(0,4)}</span>}
              {formatRuntime(movie.runtime)&&<span style={{fontSize:12,padding:"3px 8px",borderRadius:99,background:"var(--bg3)",color:"var(--text2)",border:"1px solid var(--border)"}}>{formatRuntime(movie.runtime)}</span>}
              <span style={{fontSize:11,padding:"3px 8px",borderRadius:99,background:"var(--green)22",color:"var(--green)",border:"1px solid var(--green)44",fontWeight:700}}>{sources.length} sources</span>
            </div>
            <button onClick={()=>{toggleFav(fav);showToast(isFav(fav.id)?"Removed from saved":"Saved! ❤️");}} style={{display:"flex",alignItems:"center",gap:6,padding:"7px 14px",borderRadius:99,border:"1px solid",borderColor:isFav(fav.id)?"var(--red)":"var(--border)",background:isFav(fav.id)?"var(--red)22":"var(--bg3)",color:isFav(fav.id)?"var(--red)":"var(--text2)",fontSize:12,fontWeight:700,cursor:"pointer"}}>
              <I.Heart fill={isFav(fav.id)?"currentColor":"none"} />{isFav(fav.id)?"Saved":"Save"}
            </button>
          </div>
        </div>

        {movie.genres?.length>0&&<div style={{display:"flex",gap:6,flexWrap:"wrap",marginTop:12}}>{movie.genres.map(g=><span key={g.id} style={{fontSize:11,padding:"3px 10px",borderRadius:99,background:"var(--accent)22",color:"var(--accent)",border:"1px solid var(--accent)44",fontWeight:600}}>{g.name}</span>)}</div>}

        <button onClick={()=>setPlayer(true)} style={{width:"100%",marginTop:14,padding:15,borderRadius:14,border:"none",background:"linear-gradient(135deg,var(--accent),var(--accent2))",color:"#fff",fontWeight:800,fontSize:16,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",gap:10,boxShadow:"0 4px 20px rgba(124,106,255,0.4)"}}>
          <I.Play /> Watch Now
          <span style={{fontSize:11,background:"rgba(255,255,255,0.2)",padding:"2px 8px",borderRadius:99}}>{sources.length} sources</span>
        </button>
      </div>

      {/* Tabs */}
      <div style={{display:"flex",margin:"18px 20px 0",background:"var(--bg3)",borderRadius:12,padding:4}}>
        {["about","cast","similar"].map(t=>(
          <button key={t} onClick={()=>setTab(t)} style={{flex:1,padding:9,borderRadius:10,border:"none",background:tab===t?"var(--bg2)":"transparent",color:tab===t?"var(--text)":"var(--text2)",fontWeight:tab===t?700:500,cursor:"pointer",fontSize:13,textTransform:"capitalize",transition:"all 0.2s"}}>
            {t}
          </button>
        ))}
      </div>

      <div style={{padding:"14px 20px 0"}}>
        {tab==="about"&&(
          <div style={{display:"flex",flexDirection:"column",gap:12}}>
            {movie.overview&&<p style={{fontSize:13,color:"var(--text2)",lineHeight:1.7,margin:0}}>{movie.overview}</p>}
            {/* Sources list */}
            <div style={{background:"var(--bg2)",border:"1px solid var(--border)",borderRadius:14,padding:14}}>
              <div style={{fontSize:12,fontWeight:700,color:"var(--text2)",marginBottom:10,textTransform:"uppercase",letterSpacing:"0.05em"}}>Available Sources</div>
              <div style={{display:"flex",flexDirection:"column",gap:6}}>
                {sources.map((s,i)=>(
                  <button key={i} onClick={()=>{setSrcIdx(i);setPlayer(true);}} style={{display:"flex",alignItems:"center",gap:10,padding:"10px 12px",borderRadius:10,border:"1px solid",borderColor:srcIdx===i?"var(--accent)":"var(--border)",background:srcIdx===i?"var(--accent)22":"var(--bg3)",cursor:"pointer",textAlign:"left"}}>
                    <div style={{width:8,height:8,borderRadius:"50%",background:srcIdx===i?"var(--accent)":"var(--text2)",flexShrink:0}} />
                    <div style={{flex:1}}>
                      <div style={{fontSize:13,fontWeight:700,color:srcIdx===i?"var(--accent)":"var(--text)"}}>{s.name}</div>
                    </div>
                    <span style={{fontSize:10,padding:"2px 7px",borderRadius:6,background:s.quality==="HD"?"var(--green)22":"var(--bg4)",color:s.quality==="HD"?"var(--green)":"var(--text2)",fontWeight:700}}>{s.quality}</span>
                  </button>
                ))}
              </div>
            </div>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
              {[{label:"Director",value:dir?.name},{label:"Status",value:movie.status},{label:"Budget",value:formatMoney(movie.budget)},{label:"Revenue",value:formatMoney(movie.revenue)},{label:"Language",value:movie.original_language?.toUpperCase()},{label:"IMDB ID",value:movie.imdb_id}].filter(x=>x.value).map(({label,value})=>(
                <div key={label} style={{background:"var(--bg2)",border:"1px solid var(--border)",borderRadius:12,padding:12}}>
                  <div style={{fontSize:10,color:"var(--text2)",marginBottom:3,textTransform:"uppercase",letterSpacing:"0.05em"}}>{label}</div>
                  <div style={{fontSize:13,fontWeight:700}}>{value}</div>
                </div>
              ))}
            </div>
          </div>
        )}
        {tab==="cast"&&(
          <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:10}}>
            {cast.length===0&&<div style={{gridColumn:"span 3",textAlign:"center",padding:30,color:"var(--text2)"}}>No cast info</div>}
            {cast.map(p=>(
              <div key={p.id} style={{background:"var(--bg2)",border:"1px solid var(--border)",borderRadius:12,overflow:"hidden",textAlign:"center"}}>
                {p.profile_path?<img src={`https://image.tmdb.org/t/p/w185${p.profile_path}`} alt={p.name} loading="lazy" style={{width:"100%",height:100,objectFit:"cover",objectPosition:"top"}} />:<div style={{width:"100%",height:100,background:"var(--bg3)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:28}}>👤</div>}
                <div style={{padding:"6px 8px"}}>
                  <div style={{fontSize:11,fontWeight:700,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{p.name}</div>
                  <div style={{fontSize:10,color:"var(--text2)",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{p.character}</div>
                </div>
              </div>
            ))}
          </div>
        )}
        {tab==="similar"&&(
          <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:10}}>
            {related.length===0&&<div style={{gridColumn:"span 3",textAlign:"center",padding:30,color:"var(--text2)"}}>No similar movies</div>}
            {related.map(m=>(
              <div key={m.id} style={{cursor:"pointer"}} onClick={()=>{setLoading(true);window.scrollTo(0,0);}}>
                <img src={posterUrl(m.poster_path,"w185")} alt={m.title} loading="lazy" style={{width:"100%",aspectRatio:"2/3",borderRadius:10,objectFit:"cover",background:"var(--bg3)"}} onError={e=>e.target.style.opacity="0"} />
                <div style={{fontSize:11,fontWeight:600,lineHeight:1.3,marginTop:5,overflow:"hidden",display:"-webkit-box",WebkitLineClamp:2,WebkitBoxOrient:"vertical"}}>{m.title}</div>
              </div>
            ))}
          </div>
        )}
      </div>

      {showPlayer&&<PlayerModal title={movie.title} sources={sources} srcIdx={srcIdx} setSrcIdx={setSrcIdx} onClose={()=>setPlayer(false)} prefLang={store.prefLang} />}
    </div>
  );
}

// ─── TV DETAIL PAGE ───────────────────────────────────────────────────────────
function TVDetail({id, store, onBack}) {
  const {toggleFav,isFav,addHistory,showToast}=store;
  const [show,    setShow]    = useState(null);
  const [loading, setLoading] = useState(true);
  const [season,  setSeason]  = useState(1);
  const [seasData,setSeasData]= useState(null);
  const [seasLoad,setSeasLoad]= useState(false);
  const [tab,     setTab]     = useState("episodes");
  const [showPlayer,setPlayer]= useState(false);
  const [playEp,  setPlayEp]  = useState({season:1,episode:1});
  const [sources, setSources] = useState([]);
  const [srcIdx,  setSrcIdx]  = useState(0);

  useEffect(()=>{
    setLoading(true);setShow(null);setSeasData(null);setTab("episodes");setSeason(1);
    getTVDetail(Number(id))
      .then(data=>{
        setShow(data);
        addHistory({id:`tv-${data.id}`,title:data.name,_repoName:"TV Shows",poster:posterUrl(data.poster_path)});
        loadSeason(data.id,1);
      })
      .catch(()=>showToast("Failed to load show","error"))
      .finally(()=>setLoading(false));
  },[id]);

  const loadSeason=async(showId,num)=>{
    setSeasLoad(true);
    try{setSeasData(await getTVSeason(showId,num));}catch{}
    setSeasLoad(false);
  };

  const handlePlay=(s,e)=>{
    setPlayEp({season:s,episode:e});
    setSources(sortSources(getTVSources(show.id,show.imdb_id,s,e), store.prefLang));
    setSrcIdx(0);setPlayer(true);
  };

  if(loading) return <div style={{display:"flex",alignItems:"center",justifyContent:"center",height:"80vh",flexDirection:"column",gap:16}}><Spinner /></div>;
  if(!show)   return <div style={{padding:40,textAlign:"center",color:"var(--text2)"}}>Show not found. <button onClick={onBack} style={{color:"var(--accent)",background:"none",border:"none",cursor:"pointer"}}>Go back</button></div>;

  const fav={id:`tv-${show.id}`,title:show.name,_repoName:"TV Shows",poster:posterUrl(show.poster_path)};
  const rating=show.vote_average?.toFixed(1);
  const seasons=(show.seasons||[]).filter(s=>s.season_number>0);
  const cast=(show.credits?.cast||[]).slice(0,12);
  const episodes=seasData?.episodes||[];
  const trailer=show.videos?.find(v=>v.type==="Trailer"&&v.site==="YouTube");

  return (
    <div style={{paddingBottom:24,animation:"sv-fadeIn 0.2s ease"}}>
      <button onClick={onBack} style={{position:"fixed",top:16,left:16,zIndex:200,background:"rgba(0,0,0,0.75)",border:"none",borderRadius:99,padding:"8px 14px",color:"#fff",cursor:"pointer",display:"flex",alignItems:"center",gap:6,fontWeight:700,fontSize:13,backdropFilter:"blur(10px)"}}>
        <I.Back /> Back
      </button>

      <div style={{position:"relative",height:250,background:"var(--bg3)"}}>
        {backdropUrl(show.backdrop_path)&&<img src={backdropUrl(show.backdrop_path)} alt="" style={{width:"100%",height:"100%",objectFit:"cover"}} />}
        <div style={{position:"absolute",inset:0,background:"linear-gradient(to bottom,rgba(0,0,0,0.1) 0%,var(--bg) 100%)"}} />
        {trailer&&<a href={`https://youtube.com/watch?v=${trailer.key}`} target="_blank" rel="noopener noreferrer" style={{position:"absolute",top:"50%",left:"50%",transform:"translate(-50%,-50%)",background:"rgba(255,255,255,0.15)",border:"2px solid rgba(255,255,255,0.8)",borderRadius:99,padding:"10px 20px",color:"#fff",fontWeight:700,fontSize:13,textDecoration:"none",display:"flex",alignItems:"center",gap:8,backdropFilter:"blur(10px)"}}>▶ Trailer</a>}
      </div>

      <div style={{padding:"0 20px",marginTop:-60,position:"relative"}}>
        <div style={{display:"flex",gap:16,alignItems:"flex-end"}}>
          {posterUrl(show.poster_path,"w342")
            ?<img src={posterUrl(show.poster_path,"w342")} alt={show.name} style={{width:110,height:160,borderRadius:14,objectFit:"cover",border:"3px solid var(--bg)",flexShrink:0,boxShadow:"0 8px 32px rgba(0,0,0,0.5)"}} />
            :<div style={{width:110,height:160,borderRadius:14,background:"var(--bg3)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:36,flexShrink:0}}>📺</div>
          }
          <div style={{flex:1,paddingBottom:4,minWidth:0}}>
            <h1 style={{fontSize:18,fontWeight:800,lineHeight:1.2,marginBottom:8,marginTop:0}}>{show.name}</h1>
            <div style={{display:"flex",gap:6,flexWrap:"wrap",marginBottom:10}}>
              {rating&&<span style={{display:"flex",alignItems:"center",gap:3,fontSize:12,padding:"3px 8px",borderRadius:99,background:"var(--yellow)22",color:"var(--yellow)",fontWeight:800,border:"1px solid var(--yellow)44"}}><I.Star />{rating}</span>}
              {show.first_air_date&&<span style={{fontSize:12,padding:"3px 8px",borderRadius:99,background:"var(--bg3)",color:"var(--text2)",border:"1px solid var(--border)"}}>{show.first_air_date.slice(0,4)}</span>}
              {seasons.length>0&&<span style={{fontSize:12,padding:"3px 8px",borderRadius:99,background:"var(--bg3)",color:"var(--text2)",border:"1px solid var(--border)"}}>{seasons.length}S</span>}
              <span style={{fontSize:11,padding:"3px 8px",borderRadius:99,background:show.status==="Returning Series"?"var(--green)22":"var(--bg3)",color:show.status==="Returning Series"?"var(--green)":"var(--text2)",border:"1px solid",borderColor:show.status==="Returning Series"?"var(--green)44":"var(--border)",fontWeight:600}}>{show.status}</span>
            </div>
            <button onClick={()=>{toggleFav(fav);showToast(isFav(fav.id)?"Removed from saved":"Saved! ❤️");}} style={{display:"flex",alignItems:"center",gap:6,padding:"7px 14px",borderRadius:99,border:"1px solid",borderColor:isFav(fav.id)?"var(--red)":"var(--border)",background:isFav(fav.id)?"var(--red)22":"var(--bg3)",color:isFav(fav.id)?"var(--red)":"var(--text2)",fontSize:12,fontWeight:700,cursor:"pointer"}}>
              <I.Heart fill={isFav(fav.id)?"currentColor":"none"} />{isFav(fav.id)?"Saved":"Save"}
            </button>
          </div>
        </div>
        {show.genres?.length>0&&<div style={{display:"flex",gap:6,flexWrap:"wrap",marginTop:12}}>{show.genres.map(g=><span key={g.id} style={{fontSize:11,padding:"3px 10px",borderRadius:99,background:"var(--cyan)22",color:"var(--cyan)",border:"1px solid var(--cyan)44",fontWeight:600}}>{g.name}</span>)}</div>}
        {show.overview&&<p style={{fontSize:13,color:"var(--text2)",lineHeight:1.7,marginTop:12,marginBottom:0}}>{show.overview}</p>}
      </div>

      {/* Tabs */}
      <div style={{display:"flex",margin:"18px 20px 0",background:"var(--bg3)",borderRadius:12,padding:4}}>
        {["episodes","cast","about"].map(t=>(
          <button key={t} onClick={()=>setTab(t)} style={{flex:1,padding:9,borderRadius:10,border:"none",background:tab===t?"var(--bg2)":"transparent",color:tab===t?"var(--text)":"var(--text2)",fontWeight:tab===t?700:500,cursor:"pointer",fontSize:13,textTransform:"capitalize",transition:"all 0.2s"}}>
            {t}
          </button>
        ))}
      </div>

      <div style={{padding:"14px 20px 0"}}>
        {tab==="episodes"&&(
          <div>
            {/* Season picker */}
            {seasons.length>1&&(
              <div style={{display:"flex",gap:6,overflowX:"auto",scrollbarWidth:"none",marginBottom:14,paddingBottom:2}}>
                {seasons.map(s=>(
                  <button key={s.season_number} onClick={()=>{setSeason(s.season_number);loadSeason(show.id,s.season_number);}} style={{flexShrink:0,padding:"7px 14px",borderRadius:10,border:"1px solid",borderColor:season===s.season_number?"var(--cyan)":"var(--border)",background:season===s.season_number?"var(--cyan)22":"var(--bg3)",color:season===s.season_number?"var(--cyan)":"var(--text2)",fontSize:12,fontWeight:700,cursor:"pointer",whiteSpace:"nowrap"}}>
                    S{s.season_number}
                  </button>
                ))}
              </div>
            )}
            {seasLoad&&<div style={{display:"flex",justifyContent:"center",padding:20}}><Spinner color="var(--cyan)" /></div>}
            {!seasLoad&&<div style={{display:"flex",flexDirection:"column",gap:8}}>
              {episodes.length===0&&<div style={{textAlign:"center",padding:30,color:"var(--text2)"}}>No episodes found</div>}
              {episodes.map(ep=>(
                <div key={ep.id} style={{background:"var(--bg2)",border:"1px solid var(--border)",borderRadius:12,padding:"10px 12px",display:"flex",alignItems:"center",gap:12}}>
                  {ep.still_path?<img src={`https://image.tmdb.org/t/p/w185${ep.still_path}`} alt={ep.name} loading="lazy" style={{width:80,height:50,borderRadius:8,objectFit:"cover",flexShrink:0,background:"var(--bg3)"}} />:<div style={{width:80,height:50,borderRadius:8,background:"var(--bg3)",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0,fontSize:20}}>📺</div>}
                  <div style={{flex:1,minWidth:0}}>
                    <div style={{fontSize:12,fontWeight:700,color:"var(--text2)",marginBottom:2}}>Ep {ep.episode_number}</div>
                    <div style={{fontSize:13,fontWeight:600,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{ep.name}</div>
                    {ep.vote_average>0&&<div style={{fontSize:11,color:"var(--yellow)",marginTop:2,display:"flex",alignItems:"center",gap:3}}><I.Star />{ep.vote_average.toFixed(1)}</div>}
                  </div>
                  <button onClick={()=>handlePlay(season,ep.episode_number)} style={{background:"var(--accent)",border:"none",borderRadius:99,width:36,height:36,display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer",color:"#fff",flexShrink:0}}>
                    <I.Play />
                  </button>
                </div>
              ))}
            </div>}
          </div>
        )}
        {tab==="cast"&&(
          <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:10}}>
            {cast.length===0&&<div style={{gridColumn:"span 3",textAlign:"center",padding:30,color:"var(--text2)"}}>No cast info</div>}
            {cast.map(p=>(
              <div key={p.id} style={{background:"var(--bg2)",border:"1px solid var(--border)",borderRadius:12,overflow:"hidden",textAlign:"center"}}>
                {p.profile_path?<img src={`https://image.tmdb.org/t/p/w185${p.profile_path}`} alt={p.name} loading="lazy" style={{width:"100%",height:100,objectFit:"cover",objectPosition:"top"}} />:<div style={{width:"100%",height:100,background:"var(--bg3)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:28}}>👤</div>}
                <div style={{padding:"6px 8px"}}>
                  <div style={{fontSize:11,fontWeight:700,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{p.name}</div>
                  <div style={{fontSize:10,color:"var(--text2)",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{p.character}</div>
                </div>
              </div>
            ))}
          </div>
        )}
        {tab==="about"&&(
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
            {[{label:"Status",value:show.status},{label:"Network",value:(show.networks||[])[0]?.name},{label:"Episodes",value:show.number_of_episodes},{label:"Seasons",value:show.number_of_seasons},{label:"Language",value:show.original_language?.toUpperCase()},{label:"IMDB ID",value:show.imdb_id}].filter(x=>x.value).map(({label,value})=>(
              <div key={label} style={{background:"var(--bg2)",border:"1px solid var(--border)",borderRadius:12,padding:12}}>
                <div style={{fontSize:10,color:"var(--text2)",marginBottom:3,textTransform:"uppercase",letterSpacing:"0.05em"}}>{label}</div>
                <div style={{fontSize:13,fontWeight:700}}>{value}</div>
              </div>
            ))}
          </div>
        )}
      </div>

      {showPlayer&&<PlayerModal title={`${show.name} S${playEp.season}E${playEp.episode}`} sources={sources} srcIdx={srcIdx} setSrcIdx={setSrcIdx} onClose={()=>setPlayer(false)} prefLang={store.prefLang} />}
    </div>
  );
}

// ─── HINDI DUB TAB (AnimeWorld India source) ─────────────────────────────────
// ⚠️  Disclaimer shown inline: content is scraped from animeworld-india.me.
//     This may stop working if the source site changes its structure.
function HindiDubTab({ animeTitle, store, preloadedMatch }) {
  const { showToast, prefLang } = store;

  // States for the multi-step AWI flow
  const [phase, setPhase]       = useState("idle");   // idle | searching | seasons | episodes | streaming | error
  const [error, setError]       = useState(null);
  const [searchResults, setSearchResults] = useState([]);
  const [seasons, setSeasons]   = useState([]);
  const [seriesMeta, setSeriesMeta] = useState(null);
  const [episodes, setEpisodes] = useState([]);
  const [seasonMeta, setSeasonMeta] = useState(null);
  const [selectedSeries, setSelectedSeries] = useState(null);
  const [selectedSeason, setSelectedSeason] = useState(null);
  const [showPlayer, setShowPlayer] = useState(false);
  const [streamSources, setStreamSources] = useState([]);
  const [srcIdx, setSrcIdx]     = useState(0);
  const [streamTitle, setStreamTitle] = useState("");
  const [loadingStream, setLoadingStream] = useState(false);

  // Auto-search, or use preloaded result from parent probe
  useEffect(() => {
    if (!animeTitle) return;
    // If parent already probed AWI, use that result — skip redundant fetch
    if (preloadedMatch !== undefined && preloadedMatch !== null) {
      if (preloadedMatch === false) {
        setPhase("no_results");
        return;
      }
      setSearchResults([preloadedMatch]);
      setPhase("search_results");
      // Auto-navigate into the series/movie directly
      pickSeries(preloadedMatch);
      return;
    }
    doSearch(animeTitle);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [animeTitle, preloadedMatch]);

  async function doSearch(q) {
    setPhase("searching"); setError(null); setSearchResults([]);
    try {
      const data = await awiSearch(q);
      if (!data.success) throw new Error(data.error || "Search failed");
      setSearchResults(data.results || []);
      setPhase(data.results?.length ? "search_results" : "no_results");
    } catch (e) {
      setError(e.message);
      setPhase("error");
    }
  }

  async function pickSeries(result) {
    setSelectedSeries(result);
    if (result.type === "movie") {
      // Movies go straight to the stream phase
      setPhase("streaming");
      return;
    }
    setPhase("seasons"); setSeasons([]); setSeriesMeta(null);
    try {
      const data = await awiSeasons(result.seriesId);
      if (!data.success) throw new Error(data.error || "Could not load seasons");
      setSeriesMeta(data.series);
      setSeasons(data.seasons || []);
    } catch (e) {
      setError(e.message); setPhase("error");
    }
  }

  async function pickSeason(season) {
    setSelectedSeason(season);
    setPhase("episodes"); setEpisodes([]); setSeasonMeta(null);
    try {
      const data = await awiEpisodes(season.seasonId);
      if (!data.success) throw new Error(data.error || "Could not load episodes");
      setSeasonMeta(data.season);
      setEpisodes(data.episodes || []);
    } catch (e) {
      setError(e.message); setPhase("error");
    }
  }

  async function playEpisode(ep) {
    setLoadingStream(true);
    try {
      const data = await awiStream({ episodeId: ep.episodeId });
      if (!data.success || !data.stream?.streamLink) {
        throw new Error(data.error || "No stream link returned");
      }
      const src = {
        name: "AnimeWorld India 🇮🇳",
        quality: "HD",
        langs: ["hi"],
        url: data.stream.streamLink,
      };
      setStreamSources([src]);
      setSrcIdx(0);
      setStreamTitle(`${selectedSeries?.title || animeTitle} – ${ep.episodeNumber || ep.episodeId}`);
      setShowPlayer(true);
    } catch (e) {
      showToast("Stream failed: " + e.message, "error");
    } finally {
      setLoadingStream(false);
    }
  }

  async function playMovie(result) {
    setLoadingStream(true);
    try {
      const data = await awiStream({ movieId: result.movieId || result.seriesId });
      if (!data.success || !data.stream?.streamLink) {
        throw new Error(data.error || "No stream link returned");
      }
      const src = {
        name: "AnimeWorld India 🇮🇳",
        quality: "HD",
        langs: ["hi"],
        url: data.stream.streamLink,
      };
      setStreamSources([src]);
      setSrcIdx(0);
      setStreamTitle(result.title || animeTitle);
      setShowPlayer(true);
    } catch (e) {
      showToast("Stream failed: " + e.message, "error");
    } finally {
      setLoadingStream(false);
    }
  }

  // Disclaimer banner
  const Caveat = () => (
    <div style={{
      background: "var(--yellow)15",
      border: "1px solid var(--yellow)44",
      borderRadius: 10,
      padding: "9px 13px",
      fontSize: 11,
      color: "var(--yellow)",
      lineHeight: 1.5,
      marginBottom: 14,
    }}>
      ⚠️ <strong>Unofficial source</strong> — content is fetched from
      animeworld-india.me via the AnimeWorld-India-Api. <em>May break if the
      source site changes its structure.</em>
    </div>
  );

  if (phase === "searching") {
    return (
      <div style={{ display: "flex", flexDirection: "column", alignItems: "center", padding: 40, gap: 14, color: "var(--text2)" }}>
        <Spinner color="var(--yellow)" />
        <div style={{ fontSize: 13 }}>Searching Hindi dub…</div>
      </div>
    );
  }

  if (phase === "error") {
    return (
      <div style={{ padding: 20 }}>
        <Caveat />
        <div style={{ background: "var(--red)15", border: "1px solid var(--red)33", borderRadius: 12, padding: 16, color: "var(--red)", fontSize: 13, lineHeight: 1.6 }}>
          <strong>Error:</strong> {error}
          {error?.includes("self-hosted") && (
            <div style={{ marginTop: 8, color: "var(--text2)", fontSize: 11 }}>
              Make sure the backend is running on port 5001, or set{" "}
              <code>VITE_API_BASE</code> in your <code>frontend/.env</code>{" "}
              to your deployed backend URL.
            </div>
          )}
        </div>
        <button onClick={() => doSearch(animeTitle)} style={{ marginTop: 12, padding: "8px 16px", borderRadius: 99, border: "1px solid var(--border)", background: "var(--bg3)", color: "var(--text2)", fontSize: 12, cursor: "pointer" }}>
          ↺ Retry
        </button>
      </div>
    );
  }

  if (phase === "no_results") {
    return (
      <div style={{ padding: 20 }}>
        <Caveat />
        <div style={{ textAlign: "center", color: "var(--text2)", padding: "30px 0", fontSize: 13 }}>
          <div style={{ fontSize: 32, marginBottom: 8 }}>🇮🇳</div>
          No Hindi dub found for <strong style={{ color: "var(--text)" }}>{animeTitle}</strong>
        </div>
      </div>
    );
  }

  if (phase === "search_results") {
    return (
      <div>
        <Caveat />
        <div style={{ fontSize: 12, color: "var(--text2)", marginBottom: 10 }}>
          Select the matching title below:
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {searchResults.map((r, i) => (
            <button key={i} onClick={() => r.type === "movie" ? playMovie(r) : pickSeries(r)}
              style={{ display: "flex", alignItems: "center", gap: 10, padding: "10px 12px", borderRadius: 12, border: "1px solid var(--border)", background: "var(--bg3)", cursor: "pointer", textAlign: "left" }}>
              {r.image && <img src={r.image} alt="" style={{ width: 44, height: 60, borderRadius: 7, objectFit: "cover", flexShrink: 0 }} />}
              <div style={{ minWidth: 0 }}>
                <div style={{ fontWeight: 700, fontSize: 13, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", color: "var(--text)" }}>{r.title}</div>
                <div style={{ fontSize: 11, color: "var(--text2)", marginTop: 3 }}>
                  {r.year && <span>{r.year} · </span>}
                  <span style={{ color: r.type === "series" ? "var(--yellow)" : "var(--accent)", fontWeight: 700, textTransform: "capitalize" }}>{r.type}</span>
                  {r.rating && <span> · ⭐ {r.rating}</span>}
                </div>
              </div>
              <div style={{ marginLeft: "auto", fontSize: 18, flexShrink: 0 }}>›</div>
            </button>
          ))}
        </div>
      </div>
    );
  }

  if (phase === "seasons") {
    return (
      <div>
        <button onClick={() => { setPhase("search_results"); setShowPlayer(false); }} style={{ marginBottom: 12, background: "none", border: "none", color: "var(--accent)", cursor: "pointer", fontSize: 12, fontWeight: 700 }}>
          ← Back
        </button>
        <Caveat />
        {seriesMeta && (
          <div style={{ fontSize: 12, color: "var(--text2)", marginBottom: 10 }}>
            {seriesMeta.title} · {seriesMeta.totalSeasons} season(s)
          </div>
        )}
        {seasons.length === 0 && <div style={{ display: "flex", justifyContent: "center", padding: 30 }}><Spinner color="var(--yellow)" /></div>}
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {seasons.map((s, i) => (
            <button key={i} onClick={() => pickSeason(s)}
              style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "12px 14px", borderRadius: 12, border: "1px solid var(--border)", background: "var(--bg3)", cursor: "pointer", textAlign: "left" }}>
              <div>
                <div style={{ fontWeight: 700, fontSize: 13, color: "var(--text)" }}>{s.seasonName}</div>
                <div style={{ fontSize: 11, color: "var(--text2)", marginTop: 3 }}>{s.episodes}</div>
              </div>
              <span style={{ fontSize: 18 }}>›</span>
            </button>
          ))}
        </div>
      </div>
    );
  }

  if (phase === "episodes") {
    return (
      <div>
        <button onClick={() => { setPhase("seasons"); setShowPlayer(false); }} style={{ marginBottom: 12, background: "none", border: "none", color: "var(--accent)", cursor: "pointer", fontSize: 12, fontWeight: 700 }}>
          ← Back
        </button>
        <Caveat />
        {seasonMeta && (
          <div style={{ fontSize: 12, color: "var(--text2)", marginBottom: 10 }}>
            {seasonMeta.seasonName} · {seasonMeta.totalEpisodes} episodes
          </div>
        )}
        {episodes.length === 0 && <div style={{ display: "flex", justifyContent: "center", padding: 30 }}><Spinner color="var(--yellow)" /></div>}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 8 }}>
          {episodes.map((ep, i) => (
            <button key={i} onClick={() => playEpisode(ep)}
              disabled={loadingStream}
              style={{ padding: "12px 6px", borderRadius: 10, border: "1px solid var(--border)", background: "var(--bg3)", color: "var(--text)", fontWeight: 700, fontSize: 12, cursor: "pointer", display: "flex", flexDirection: "column", alignItems: "center", gap: 4, opacity: loadingStream ? 0.6 : 1 }}>
              {loadingStream ? <Spinner color="var(--yellow)" /> : <I.Play />}
              <span style={{ fontSize: 10 }}>{i + 1}</span>
            </button>
          ))}
        </div>
        {showPlayer && (
          <PlayerModal
            title={streamTitle}
            sources={streamSources}
            srcIdx={srcIdx}
            setSrcIdx={setSrcIdx}
            onClose={() => setShowPlayer(false)}
            prefLang={prefLang}
          />
        )}
      </div>
    );
  }

  if (phase === "streaming") {
    // Movie: trigger load immediately
    if (!showPlayer && !loadingStream && selectedSeries) {
      playMovie(selectedSeries);
    }
    return (
      <div style={{ display: "flex", flexDirection: "column", alignItems: "center", padding: 40, gap: 14, color: "var(--text2)" }}>
        <Spinner color="var(--yellow)" />
        <div style={{ fontSize: 13 }}>Fetching stream…</div>
        {showPlayer && (
          <PlayerModal
            title={streamTitle}
            sources={streamSources}
            srcIdx={srcIdx}
            setSrcIdx={setSrcIdx}
            onClose={() => { setShowPlayer(false); setPhase("search_results"); }}
            prefLang={prefLang}
          />
        )}
      </div>
    );
  }

  // idle state — shouldn't normally render, but show spinner gracefully
  return (
    <div style={{ display: "flex", justifyContent: "center", padding: 40 }}>
      <Spinner color="var(--yellow)" />
    </div>
  );
}

// ─── ANIME DETAIL PAGE ────────────────────────────────────────────────────────
function AnimeDetail({id, store, onBack}) {
  const {toggleFav,isFav,addHistory,showToast}=store;
  const [anime,   setAnime]   = useState(null);
  const [loading, setLoading] = useState(true);
  const [selEp,   setSelEp]   = useState(1);
  const [tab,     setTab]     = useState("episodes");
  const [showPlayer,setPlayer]= useState(false);
  const [sources, setSources] = useState([]);
  const [srcIdx,  setSrcIdx]  = useState(0);
  const [epPage,  setEpPage]  = useState(0);
  // AWI probe — null=loading, false=none found, object=matched series
  const [awiMatch,   setAwiMatch]   = useState(null);
  const [awiChecked, setAwiChecked] = useState(false);

  useEffect(()=>{
    setLoading(true);setAnime(null);setTab("episodes");setEpPage(0);
    setAwiMatch(null);setAwiChecked(false);
    getAnimeDetail(Number(id))
      .then(data=>{
        if(!data) throw new Error("Not found");
        setAnime(data);
        const title=data.title?.english||data.title?.romaji||"";
        addHistory({id:`anime-${data.id}`,title,_repoName:"Anime",poster:data.coverImage?.large});
        // Probe AWI in the background — don't block the UI
        awiSearch(title)
          .then(awiData=>{
            const firstMatch=awiData?.results?.[0]||null;
            setAwiMatch(firstMatch||false);
            console.log("[AWI Probe]",title,"→",firstMatch
              ?`found: ${firstMatch.title} (${firstMatch.type})`
              :"no Hindi dub found");
          })
          .catch(e=>{
            console.warn("[AWI Probe] Failed:",e.message);
            setAwiMatch(false);
          })
          .finally(()=>setAwiChecked(true));
      })
      .catch(()=>showToast("Failed to load anime","error"))
      .finally(()=>setLoading(false));
  },[id]);

  const handlePlay=async(ep)=>{
    const title=anime.title?.english||anime.title?.romaji||"";
    const baseSources=sortSources(getAnimeSources(title,ep,anime.idMal,anime.id),store.prefLang);
    // Open the player immediately with base sources so the user isn't blocked
    setSources(baseSources);setSrcIdx(0);setSelEp(ep);setPlayer(true);
    // If we have an AWI match, try to inject a Hindi Dub source in the background
    if(awiMatch&&awiMatch.type==="series"&&awiMatch.seriesId){
      try{
        const seasonsData=await awiSeasons(awiMatch.seriesId);
        const firstSeason=seasonsData?.seasons?.[0];
        if(firstSeason){
          const epsData=await awiEpisodes(firstSeason.seasonId);
          const targetEp=epsData?.episodes?.find(e=>{
            const n=parseInt(e.episodeNumber?.replace(/\D/g,"")||"0");
            return n===ep;
          })||epsData?.episodes?.[ep-1];
          if(targetEp){
            const streamData=await awiStream({episodeId:targetEp.episodeId});
            if(streamData?.stream?.streamLink){
              const hindiSource={
                name:"AnimeWorld India 🇮🇳 (Hindi Dub)",
                quality:"HD",langs:["hi"],
                url:streamData.stream.streamLink,
                isAWI:true,
              };
              setSources(prev=>{
                const deduped=prev.filter(s=>!s.isAWI);
                return sortSources([hindiSource,...deduped],store.prefLang);
              });
              console.log("[AWI] Injected Hindi Dub source for ep",ep);
            }
          }
        }
      }catch(e){
        console.warn("[AWI] Could not inject Hindi source:",e.message);
        // Silently fall back — baseSources are already showing in the player
      }
    }
  };

  if(loading) return <div style={{display:"flex",alignItems:"center",justifyContent:"center",height:"80vh",flexDirection:"column",gap:16}}><Spinner color="var(--yellow)" /></div>;
  if(!anime)  return <div style={{padding:40,textAlign:"center",color:"var(--text2)"}}>Anime not found. <button onClick={onBack} style={{color:"var(--accent)",background:"none",border:"none",cursor:"pointer"}}>Go back</button></div>;

  const title=anime.title?.english||anime.title?.romaji||"Unknown";
  const rating=anime.averageScore?(anime.averageScore/10).toFixed(1):null;
  const totalEp=anime.episodes||12;
  const fav={id:`anime-${anime.id}`,title,_repoName:"Anime",poster:anime.coverImage?.large};
  const relations=(anime.relations?.edges||[]).filter(e=>["SEQUEL","PREQUEL","SIDE_STORY","SPIN_OFF"].includes(e.relationType)).slice(0,6);
  const EPS_PER_PAGE=24;
  const epStart=epPage*EPS_PER_PAGE+1;
  const epEnd=Math.min((epPage+1)*EPS_PER_PAGE,totalEp);
  const epPages=Math.ceil(totalEp/EPS_PER_PAGE);

  return (
    <div style={{paddingBottom:24,animation:"sv-fadeIn 0.2s ease"}}>
      <button onClick={onBack} style={{position:"fixed",top:16,left:16,zIndex:200,background:"rgba(0,0,0,0.75)",border:"none",borderRadius:99,padding:"8px 14px",color:"#fff",cursor:"pointer",display:"flex",alignItems:"center",gap:6,fontWeight:700,fontSize:13,backdropFilter:"blur(10px)"}}>
        <I.Back /> Back
      </button>

      <div style={{position:"relative",height:250,background:"var(--bg3)"}}>
        {(anime.bannerImage||anime.coverImage?.extraLarge)&&<img src={anime.bannerImage||anime.coverImage?.extraLarge} alt="" style={{width:"100%",height:"100%",objectFit:"cover"}} />}
        <div style={{position:"absolute",inset:0,background:"linear-gradient(to bottom,rgba(0,0,0,0.1) 0%,var(--bg) 100%)"}} />
      </div>

      <div style={{padding:"0 20px",marginTop:-60,position:"relative"}}>
        <div style={{display:"flex",gap:16,alignItems:"flex-end"}}>
          {anime.coverImage?.large
            ?<img src={anime.coverImage.large} alt={title} style={{width:110,height:160,borderRadius:14,objectFit:"cover",border:"3px solid var(--bg)",flexShrink:0,boxShadow:"0 8px 32px rgba(0,0,0,0.5)"}} />
            :<div style={{width:110,height:160,borderRadius:14,background:"var(--bg3)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:36,flexShrink:0}}>⚔️</div>
          }
          <div style={{flex:1,paddingBottom:4,minWidth:0}}>
            <h1 style={{fontSize:16,fontWeight:800,lineHeight:1.2,marginBottom:8,marginTop:0}}>{title}</h1>
            {anime.title?.romaji&&anime.title?.english&&<div style={{fontSize:11,color:"var(--text2)",marginBottom:8}}>{anime.title.romaji}</div>}
            <div style={{display:"flex",gap:6,flexWrap:"wrap",marginBottom:10}}>
              {rating&&<span style={{display:"flex",alignItems:"center",gap:3,fontSize:12,padding:"3px 8px",borderRadius:99,background:"var(--yellow)22",color:"var(--yellow)",fontWeight:800,border:"1px solid var(--yellow)44"}}><I.Star />{rating}</span>}
              {anime.seasonYear&&<span style={{fontSize:12,padding:"3px 8px",borderRadius:99,background:"var(--bg3)",color:"var(--text2)",border:"1px solid var(--border)"}}>{anime.seasonYear}</span>}
              {anime.episodes&&<span style={{fontSize:12,padding:"3px 8px",borderRadius:99,background:"var(--bg3)",color:"var(--text2)",border:"1px solid var(--border)"}}>{anime.episodes} eps</span>}
              <span style={{fontSize:11,padding:"3px 8px",borderRadius:99,background:anime.status==="RELEASING"?"var(--green)22":"var(--bg3)",color:anime.status==="RELEASING"?"var(--green)":"var(--text2)",border:"1px solid",borderColor:anime.status==="RELEASING"?"var(--green)44":"var(--border)",fontWeight:600}}>{anime.status}</span>
            </div>
            <button onClick={()=>{toggleFav(fav);showToast(isFav(fav.id)?"Removed from saved":"Saved! ❤️");}} style={{display:"flex",alignItems:"center",gap:6,padding:"7px 14px",borderRadius:99,border:"1px solid",borderColor:isFav(fav.id)?"var(--red)":"var(--border)",background:isFav(fav.id)?"var(--red)22":"var(--bg3)",color:isFav(fav.id)?"var(--red)":"var(--text2)",fontSize:12,fontWeight:700,cursor:"pointer"}}>
              <I.Heart fill={isFav(fav.id)?"currentColor":"none"} />{isFav(fav.id)?"Saved":"Save"}
            </button>
          </div>
        </div>
        {anime.genres?.length>0&&<div style={{display:"flex",gap:6,flexWrap:"wrap",marginTop:12}}>{anime.genres.map(g=><span key={g} style={{fontSize:11,padding:"3px 10px",borderRadius:99,background:"var(--yellow)22",color:"var(--yellow)",border:"1px solid var(--yellow)44",fontWeight:600}}>{g}</span>)}</div>}
      </div>

      {/* Tabs */}
      <div style={{display:"flex",margin:"18px 20px 0",background:"var(--bg3)",borderRadius:12,padding:4}}>
        {[
          {key:"episodes", label:"Episodes"},
          {
            key:"hindi",
            label: awiMatch
              ? "🇮🇳 Hindi Dub ✓"
              : awiChecked
                ? "🇮🇳 Hindi Dub"
                : "🇮🇳 Hindi Dub…",
          },
          {key:"about",    label:"About"},
          {key:"related",  label:"Related"},
        ].map(t=>(
          <button key={t.key} onClick={()=>setTab(t.key)} style={{
            flex:1,padding:9,borderRadius:10,border:"none",
            background:tab===t.key?"var(--bg2)":"transparent",
            color:tab===t.key
              ?(t.key==="hindi"&&awiMatch?"var(--yellow)":"var(--text)")
              :"var(--text2)",
            fontWeight:tab===t.key?700:500,
            cursor:"pointer",
            fontSize:t.key==="hindi"?10:13,
            textTransform:"capitalize",
            transition:"all 0.2s",
            outline:t.key==="hindi"&&awiMatch&&tab!=="hindi"?"1px solid var(--yellow)44":"none",
          }}>
            {t.label}
          </button>
        ))}
      </div>

      <div style={{padding:"14px 20px 0"}}>
        {tab==="hindi"&&(
          <HindiDubTab animeTitle={title} store={store} preloadedMatch={awiMatch} />
        )}
        {tab==="episodes"&&(
          <div>
            {/* Quick play button */}
            <button onClick={()=>handlePlay(1)} style={{width:"100%",marginBottom:14,padding:14,borderRadius:14,border:"none",background:"linear-gradient(135deg,var(--yellow),#e67e22)",color:"#fff",fontWeight:800,fontSize:15,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",gap:10}}>
              <I.Play /> Watch Episode 1
            </button>
            {/* Episode page nav */}
            {epPages>1&&(
              <div style={{display:"flex",gap:6,overflowX:"auto",scrollbarWidth:"none",marginBottom:12,paddingBottom:2}}>
                {Array.from({length:epPages},(_,i)=>(
                  <button key={i} onClick={()=>setEpPage(i)} style={{flexShrink:0,padding:"6px 12px",borderRadius:99,border:"1px solid",borderColor:epPage===i?"var(--yellow)":"var(--border)",background:epPage===i?"var(--yellow)22":"var(--bg3)",color:epPage===i?"var(--yellow)":"var(--text2)",fontSize:12,fontWeight:700,cursor:"pointer",whiteSpace:"nowrap"}}>
                    {i*EPS_PER_PAGE+1}–{Math.min((i+1)*EPS_PER_PAGE,totalEp)}
                  </button>
                ))}
              </div>
            )}
            <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:8}}>
              {Array.from({length:epEnd-epStart+1},(_,i)=>epStart+i).map(ep=>(
                <button key={ep} onClick={()=>handlePlay(ep)} style={{padding:"12px 6px",borderRadius:10,border:"1px solid",borderColor:selEp===ep?"var(--yellow)":"var(--border)",background:selEp===ep?"var(--yellow)22":"var(--bg3)",color:selEp===ep?"var(--yellow)":"var(--text)",fontWeight:700,fontSize:13,cursor:"pointer",display:"flex",flexDirection:"column",alignItems:"center",gap:4,position:"relative"}}>
                  <I.Play />
                  <span style={{fontSize:11}}>{ep}</span>
                  {awiMatch&&<span style={{position:"absolute",top:3,right:3,fontSize:7,lineHeight:1,background:"var(--yellow)",color:"#000",borderRadius:3,padding:"1px 3px",fontWeight:800}}>HI</span>}
                </button>
              ))}
            </div>
          </div>
        )}
        {tab==="about"&&(
          <div style={{display:"flex",flexDirection:"column",gap:12}}>
            {anime.description&&<p style={{fontSize:13,color:"var(--text2)",lineHeight:1.7,margin:0}} dangerouslySetInnerHTML={{__html:anime.description.replace(/<[^>]+>/g," ")}} />}
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
              {[{label:"Format",value:anime.format},{label:"Status",value:anime.status},{label:"Season",value:anime.season&&anime.seasonYear?`${anime.season} ${anime.seasonYear}`:null},{label:"Episodes",value:anime.episodes},{label:"Studio",value:(anime.studios?.nodes||[])[0]?.name},{label:"Score",value:anime.averageScore?`${anime.averageScore}/100`:null}].filter(x=>x.value).map(({label,value})=>(
                <div key={label} style={{background:"var(--bg2)",border:"1px solid var(--border)",borderRadius:12,padding:12}}>
                  <div style={{fontSize:10,color:"var(--text2)",marginBottom:3,textTransform:"uppercase",letterSpacing:"0.05em"}}>{label}</div>
                  <div style={{fontSize:13,fontWeight:700}}>{value}</div>
                </div>
              ))}
            </div>
          </div>
        )}
        {tab==="related"&&(
          <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:10}}>
            {relations.length===0&&<div style={{gridColumn:"span 3",textAlign:"center",padding:30,color:"var(--text2)"}}>No related anime</div>}
            {relations.map(e=>{
              const node=e.node;
              const t=node.title?.english||node.title?.romaji||"?";
              return (
                <div key={node.id} style={{cursor:"pointer"}}>
                  {node.coverImage?.large?<img src={node.coverImage.large} alt={t} loading="lazy" style={{width:"100%",aspectRatio:"2/3",borderRadius:10,objectFit:"cover",background:"var(--bg3)"}} />:<div style={{width:"100%",aspectRatio:"2/3",borderRadius:10,background:"var(--bg3)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:24}}>⚔️</div>}
                  <div style={{fontSize:11,fontWeight:700,lineHeight:1.3,marginTop:5,overflow:"hidden",display:"-webkit-box",WebkitLineClamp:2,WebkitBoxOrient:"vertical"}}>{t}</div>
                  <div style={{fontSize:10,color:"var(--yellow)",marginTop:2}}>{e.relationType}</div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {showPlayer&&<PlayerModal title={`${title} - Episode ${selEp}`} sources={sources} srcIdx={srcIdx} setSrcIdx={setSrcIdx} onClose={()=>setPlayer(false)} prefLang={store.prefLang} />}
    </div>
  );
}

// ─── ROOT APP ─────────────────────────────────────────────────────────────────
export default function StreamVault() {
  const store = useAppStore();
  const {theme, toast} = store;
  const vars = theme==="dark" ? DARK : LIGHT;

  const [page,   setPage]   = useState("home");
  const [detail, setDetail] = useState(null); // {type:"movie"|"tv"|"anime", id}

  const goBack = () => setDetail(null);

  const cssVarsStyle = Object.entries(vars).reduce((s,[k,v])=>({...s,[k]:v}),{});

  return (
    <div style={{
      ...cssVarsStyle,
      background:"var(--bg)",
      color:"var(--text)",
      minHeight:"100vh",
      fontFamily:"-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif",
      position:"relative",
    }}>
      <style>{`
        @keyframes sv-spin { to { transform: rotate(360deg); } }
        @keyframes sv-fadeIn { from { opacity: 0; } to { opacity: 1; } }
        * { box-sizing: border-box; margin: 0; padding: 0; }
        ::-webkit-scrollbar { display: none; }
        input { font-family: inherit; }
        button { font-family: inherit; }
        iframe { display: block; }
      `}</style>

      {/* Detail views */}
      {detail ? (
        <div style={{paddingBottom:72}}>
          {detail.type==="movie" && <MovieDetail key={`movie-${detail.id}`} id={detail.id} store={store} onBack={goBack} />}
          {detail.type==="tv"     && <TVDetail    key={`tv-${detail.id}`}    id={detail.id} store={store} onBack={goBack} />}
          {detail.type==="anime" && <AnimeDetail key={`anime-${detail.id}`} id={detail.id} store={store} onBack={goBack} />}
        </div>
      ) : (
        <div style={{paddingBottom:72}}>
          {page==="home"     && <HomePage     setPage={setPage} setDetail={setDetail} favs={store.favs} history={store.history} />}
          {page==="search"   && <SearchPage   setDetail={setDetail} />}
          {page==="favs"     && <FavoritesPage favs={store.favs} toggleFav={store.toggleFav} showToast={store.showToast} setDetail={setDetail} setPage={setPage} />}
          {page==="settings" && <SettingsPage  theme={theme} toggleTheme={store.toggleTheme} favs={store.favs} history={store.history} clearHistory={store.clearHistory} showToast={store.showToast} prefLang={store.prefLang} setPrefLang={store.setPrefLang} />}
        </div>
      )}

      {/* Bottom nav — hide when player is open */}
      <BottomNav page={detail ? null : page} setPage={(p)=>{setDetail(null);setPage(p);}} />

      {/* Toast */}
      <Toast toast={toast} />
    </div>
  );
}
